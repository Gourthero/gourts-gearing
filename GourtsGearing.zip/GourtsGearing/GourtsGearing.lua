-- Gourt's Gearing (formerly GearPath): tank warrior pre-raid gear guide for WoW: Forever.
-- Minimap button: left-click = menu, right-click = arrow window, drag = move.
-- /gp          open the menu
-- /gp arrow    show or hide the arrow window
-- /gp set      cycle through your spec's gear sets
-- /gp spec     pick class / spec / set
-- /gp autotick  toggle auto-ticking items you own
-- /gp glow     toggle bag highlights
-- /gp reset    clear ticked items and progress
-- /gp gourt, /gp big gourt, /gp raze   you'll see

local ADDON, NS = ...
NS = NS or {}

------------------------------------------------------------------------
-- Routes: step-by-step legs to a place. Legs with a waypoint get an arrow
-- and move on by themselves when you arrive. approx = rough area only.
------------------------------------------------------------------------
local ROUTES = {
  BOOTY = { name = "Booty Bay (Pix Xizzix)", zone = "Stranglethorn Vale", legs = {
    { text = "Alliance: take the flight from Stormwind to Booty Bay.", faction = "Alliance" },
    { text = "Horde: fly to Booty Bay, or take the boat from Ratchet.", faction = "Horde" },
    { text = "Walk to Pix Xizzix, the Undermine Trader, on the Booty Bay harbour.", wp = { "Stranglethorn Vale", 28.4, 75.8 } },
  }},
  DM = { name = "Dire Maul", zone = "Feralas", legs = {
    { text = "Fly to Camp Mojache in Feralas. The arrow points to the flight master once you're in Feralas.", wp = { "Feralas", 75.5, 44.3 }, faction = "Horde" },
    { text = "Fly to Thalanaar on the east edge of Feralas. The arrow points there once you're in Feralas.", wp = { "Feralas", 89.5, 45.8, approx = true }, faction = "Alliance" },
    { text = "Ride west to the Dire Maul gate.", wp = { "Feralas", 59.0, 45.0 } },
    { text = "Summon your group at the Meeting Stone just inside.", wp = { "Feralas", 58.0, 44.5 } },
    { text = "In the courtyard: the EAST wing (Warpwood Quarter) needs no key. WEST is the Capital Gardens, NORTH is Gordok Commons." },
  }},
  BRM = { name = "Blackrock Mountain (BRD / Blackrock Spire)", zone = "Searing Gorge", legs = {
    { text = "Fly to Thorium Point in Searing Gorge.", wp = { "Searing Gorge", 38.0, 30.8 }, faction = "Alliance" },
    { text = "Fly to Thorium Point in Searing Gorge.", wp = { "Searing Gorge", 34.8, 30.6 }, faction = "Horde" },
    { text = "Ride south through the gorge to the Blackrock Mountain gate.", wp = { "Searing Gorge", 34.8, 83.8, approx = true } },
    { text = "Inside the mountain: go DOWN the chains for Blackrock Depths, or UP the path for Blackrock Spire (UBRS needs the Seal of Ascension)." },
  }},
  BMH = { name = "Blackmaw Hold", zone = "Azshara", legs = {
    { text = "Fly to Azshara (Alliance: Talrendis Point, Horde: Valormok)." },
    { text = "Ride to the furbolg tunnel in northern Azshara, next to the Meeting Stone.", wp = { "Azshara", 38.7, 33.4 } },
    { text = "Follow the tunnel to the instance portal near the Winterspring border." },
  }},
  MARA = { name = "Maraudon", zone = "Desolace", legs = {
    { text = "Fly to Nijel's Point in Desolace.", faction = "Alliance" },
    { text = "Fly to Shadowprey Village in Desolace.", faction = "Horde" },
    { text = "Ride to Maraudon, the centaur canyon on the west side of Desolace.", wp = { "Desolace", 29.0, 62.5, approx = true } },
    { text = "Go in through the cave to the instance portal." },
  }},
  STRAT = { name = "Stratholme", zone = "Eastern Plaguelands", legs = {
    { text = "Fly to Light's Hope Chapel in Eastern Plaguelands." },
    { text = "Ride north-west to Stratholme. For Baron Rivendare use the Service Entrance (back gate) on the east side of the city." },
  }},
  KROL = { name = "Krol'dok Stronghold", zone = "Riverglades", legs = {
    { text = "Travel to the Riverglades (Eastern Kingdoms), north of Sunnyglade." },
    { text = "Ride to the small cave west of the fortress gates.", wp = { "Riverglades", 37.5, 37.2, approx = true } },
  }},
  SCHOLO = { name = "Scholomance", zone = "Western Plaguelands", legs = {
    { text = "Someone in the group needs the Skeleton Key (Scholomance key quest)." },
    { text = "Fly to Chillwind Camp in Western Plaguelands.", faction = "Alliance" },
    { text = "Fly to the Bulwark in Western Plaguelands.", faction = "Horde" },
    { text = "Ride to Caer Darrow, the island in the lake in south-east Western Plaguelands. Scholomance is the crypt in the keep.", wp = { "Western Plaguelands", 69.7, 73.2, approx = true } },
  }},
  SHAPER = { name = "Shaper's Terrace", zone = "Un'Goro Crater", legs = {
    { text = "Fly to Un'Goro Crater (Marshal's Refuge), or to Gadgetzan / Cenarion Hold and ride in." },
    { text = "Follow the arrow to the Shaper's Terrace entrance (Wowhead's map pin).", wp = { "Kalimdor", 49.4, 76.1, approx = true, continent = true } },
  }},
  ALCAZ = { name = "Alcaz Prison", zone = "Dustwallow Marsh", legs = {
    { text = "Travel to Dustwallow Marsh. Alcaz Prison is the new dungeon on Alcaz Island, off the coast." },
  }},
  AV = { name = "Alterac Valley vendor", zone = "Alterac Mountains", legs = {
    { text = "Go to Thanthaldis Snowgleam in Alterac Mountains.", wp = { "Alterac Mountains", 39.4, 81.7 }, faction = "Alliance" },
    { text = "Go to Jekyll Flandring in Alterac Mountains.", wp = { "Alterac Mountains", 62.8, 59.3 }, faction = "Horde" },
  }},
}

------------------------------------------------------------------------
-- Items. A step { route = "DM" } expands into that route's legs.
------------------------------------------------------------------------
local PIX_REALS = "Every level 55+ dungeon boss gives 1 Tarnished Undermine Real per day (BRD, Blackrock Spire, Dire Maul, Stratholme, Scholomance). Click Next once you have enough."
local function pix(n, item)
  return {
    { text = "Collect " .. n .. " Reals. " .. PIX_REALS },
    { route = "BOOTY" },
    { text = "Talk to Pix Xizzix and buy " .. item .. ". Then click Got it!" },
  }
end

local ITEMS = {
  { name = "Furbolg Berserker's Boots", slot = "Feet", diff = 1, cat = "AH", cost = "AH price", where = "Auction House, or Blackmaw Hold drop", dungeon = "BMH", steps = {
    { text = "Check the Auction House for \"Furbolg Berserker\". Bind on Equip, so buying is fastest. Found? Click Got it!" },
    { route = "BMH" },
    { text = "Kill the Blackmaw furbolgs inside. Rare drop (about 1-3%). Bosses give Reals too." },
  }},
  { name = "Lionheart Helm", slot = "Head", diff = 1, cat = "AH", cost = "Materials", where = "Auction House or a blacksmith", steps = {
    { text = "Check the Auction House for Lionheart Helm (Bind on Equip). Found? Click Got it!" },
    { text = "Buy mats: 80 Thorium Bar, 12 Arcanite Bar, 40 Wicked Claw, 10 Blue Sapphire, 4 Azerothian Diamond." },
    { text = "Post in Trade: \"LF Blacksmith with Lionheart Helm plans, have mats\". Trade them the mats and tip." },
  }},
  { name = "Stalwart Cloak", slot = "Back", diff = 1, cat = "PIX", cost = "75 Reals", where = "Pix Xizzix, Booty Bay", steps = pix(75, "Stalwart Cloak (75)") },
  { name = "Cutthroat's Signet", slot = "Ring", diff = 1, cat = "PIX", cost = "75 Reals", where = "Pix Xizzix, Booty Bay", steps = pix(75, "Cutthroat's Signet (75)") },
  { name = "Satyr's Bow", slot = "Ranged", diff = 1, cat = "DUNGEON", cost = "Free", where = "Dire Maul East, Zevrim Thornhoof", dungeon = "DM", steps = {
    { route = "DM" },
    { text = "Enter the EAST wing. Kill Zevrim Thornhoof and roll Need on Satyr's Bow. Loot any Codex of Defense you see (for the Royal Seal)." },
  }},
  { name = "Valiant's Waistguard", slot = "Waist", diff = 2, cat = "PIX", cost = "~100 Reals", where = "Pix Xizzix, Booty Bay", steps = pix(100, "Valiant's Waistguard (about 100, check the price)") },
  { name = "Adaptive Combat Assistant", slot = "Trinket", diff = 2, cat = "PIX", cost = "125 Reals", where = "Pix Xizzix, Booty Bay", steps = pix(125, "Adaptive Combat Assistant (125)") },
  { name = "Horn of Ve'han", slot = "Neck", diff = 2, cat = "QUEST", cost = "Free", where = "Mount Hyjal quest chain", steps = {
    { text = "Fly to Everlook in Winterspring and set your Hearthstone at the inn." },
    { text = "Ride south through Winterspring to Darkwhisper Gorge at its southern end. It leads up into Mount Hyjal." },
    { text = "Talk to Sefira Everbright: \"To the Summit of Eternity\".", wp = { "Mount Hyjal", 15.6, 54.6 }, faction = "Alliance", auto = true },
    { text = "Talk to Zet'gan: \"To the Summit of Eternity\".", wp = { "Mount Hyjal", 14.0, 54.8 }, faction = "Horde", auto = true },
    { text = "South-west to the hermit Ketharas (Hermit's Abode). Do his quests. Get the Tainted Foothills flight path from Bluebell." },
    { text = "Velician (west of Felblood Scar): \"The Dying God\" -> Curious Crow -> \"An Oldstone But An Old Friend\" -> Ketharas." },
    { text = "Moonglade, Dendrite Starblaze: \"The Ancient, Orokai\", \"Stolen Power\", then bring \"The Pact\" to Ketharas." },
    { text = "For Ketharas: Stolen Life (Marrosis, Mourning's Rest), A Bit of the Sky (Skylord Omnuron, Shrine of Aviana), Ashes of the Legion Ascent (Renalard, Dae'gun)." },
    { text = "Turn them in to Ketharas and accept \"The Staff of the Mountain\"." },
    { text = "Bring the staff to Tiala Whitemane at the Summit of Eternity (indoors, next to Thisalee Crow).", wp = { "Mount Hyjal", 68.8, 50.4, approx = true }, auto = true },
    { text = "Paying Back the Pact: use the staff on 10 Blackthorne Pact members north-east of the Summit, then kill them. Group recommended." },
    { text = "Ve'han's Fall: use the staff on Ve'han Talongrasp (level 60 elite), then kill him. Bring 2-3 people." },
    { text = "Return to Ketharas, turn in \"Work Well Done\" and pick Horn of Ve'han." },
  }},
  { name = "Royal Seal of Eldre'Thalas", slot = "Trinket", diff = 3, cat = "DUNGEON", cost = "Free", where = "Dire Maul book quest", dungeon = "DM", steps = {
    { text = "Get the warrior book \"Codex of Defense\". Random Dire Maul drop, sometimes on the AH." },
    { route = "DM" },
    { text = "Enter the WEST wing and clear to the Athenaeum (library). Turn in \"Codex of Defense\" and pick the warrior seal. Bring 1 Pristine Black Diamond, 4 Large Brilliant Shards, 2 Frayed Abomination Stitching just in case." },
  }},
  { name = "Ironfoe", slot = "Main hand", diff = 3, cat = "DUNGEON", cost = "Free", where = "Blackrock Depths, Emperor Thaurissan", dungeon = "BRM", steps = {
    { route = "BRM" },
    { text = "Go DOWN to the Blackrock Depths portal. Clear to Emperor Dagran Thaurissan (last boss) and roll Need on Ironfoe. Repeat until it drops (about 10 Reals per clear)." },
  }},
  { name = "Handcrafted Mastersmith Leggings", slot = "Legs", diff = 3, cat = "DUNGEON", cost = "Free", where = "Upper Blackrock Spire, Goraluk Anvilcrack", dungeon = "BRM", steps = {
    { text = "Make sure someone in the group has the Seal of Ascension (UBRS key; quest from Vaelan in Lower Blackrock Spire)." },
    { route = "BRM" },
    { text = "Go UP to the Blackrock Spire portal and through the Upper Blackrock Spire door. Kill Goraluk Anvilcrack, roll Need. Talk to Awbee after the arena (chest quest)." },
  }},
  { name = "The Immovable Object", slot = "Off hand", diff = 4, cat = "PVP", cost = "~80g", where = "Alterac Valley, Exalted", steps = {
    { text = "Play Alterac Valley until Exalted with Stormpike Guard (Alliance) or Frostwolf Clan (Horde). Click Next when Exalted." },
    { route = "AV" },
    { text = "Buy The Immovable Object (about 80g)." },
  }},
  { name = "Don Julio's Band", slot = "Ring", diff = 4, cat = "PVP", cost = "~76g", where = "Alterac Valley, Exalted", steps = {
    { text = "Same Alterac Valley Exalted reputation as the shield." },
    { route = "AV" },
    { text = "Buy Don Julio's Band (about 76g)." },
  }},
  { name = "Breastplate of the Chromatic Flight", slot = "Chest", diff = 4, cat = "QUEST", cost = "Materials", where = "Long quest chain, UBRS start", dungeon = "BRM", steps = {
    { route = "BRM" },
    { text = "In Upper Blackrock Spire, talk to Awbee (ledge overlooking the city, right after the arena). Get Awbee's Scale." },
    { text = "Go to the Mazthoril caves in Winterspring (near Everlook). Stand on a blue rune holding the scale to teleport to Haleh." },
    { text = "Give Haleh the scale.", wp = { "Mount Hyjal", 94.1, 8.4 }, auto = true },
    { text = "Do \"Wrath of the Blue Flight\" (2 parts) and \"Catalogue of the Wayward\" (Classic: upstairs in the Andorhal inn, Western Plaguelands)." },
    { text = "Collect: 1 Chromatic Carapace (very rare, Gyth in UBRS), 10 Brilliant Chromatic Scale (AH), 10 Blood of Heroes (Eastern Plaguelands ground), 10 Frayed Abomination Stitching." },
    { text = "Bring it all to Jeziba the 'Sculptor' (follow your quest map marker)." },
  }},
  -- Broke boi set only
  { name = "Spaulders of Containment", slot = "Shoulder", diff = 1, cat = "AH", cost = "AH price", where = "Auction House, or Alcaz Prison drop", sets = { budget = true }, steps = {
    { text = "Check the Auction House for \"Spaulders of Containment\" (Bind on Equip, mail). Found? Click Got it!" },
    { text = "Otherwise: they drop in Alcaz Prison, the new dungeon on Alcaz Island off Dustwallow Marsh. No drop rate known yet." },
  }},
  { name = "Zarmok's Plated Signet", slot = "Ring", diff = 1, cat = "DUNGEON", cost = "Free", where = "Krol'dok Stronghold, Twilight Commander Zarmok", dungeon = "KROL", sets = { budget = true }, steps = {
    { route = "KROL" },
    { text = "Kill Twilight Commander Zarmok (2nd boss) and roll Need. Level 40 dungeon, so it's fast at 60." },
  }},
  { name = "Thrash Blade", slot = "Main hand", diff = 1, cat = "QUEST", cost = "Free", where = "Maraudon quest: Corruption of Earth and Seed", dungeon = "MARA", sets = { budget = true }, steps = {
    { text = "Take \"Corruption of Earth and Seed\" from Keeper Marandis at Nijel's Point.", wp = { "Desolace", 63.8, 10.7 }, faction = "Alliance", auto = true },
    { text = "Take \"Corruption of Earth and Seed\" from Selendra near Shadowprey Village.", wp = { "Desolace", 26.9, 77.7 }, faction = "Horde", auto = true },
    { route = "MARA" },
    { text = "Clear to Princess Theradras (last boss) and kill her." },
    { text = "Return to Keeper Marandis and pick Thrash Blade.", wp = { "Desolace", 63.8, 10.7 }, faction = "Alliance" },
    { text = "Return to Selendra and pick Thrash Blade.", wp = { "Desolace", 26.9, 77.7 }, faction = "Horde" },
  }},
  { name = "Reiver Claws", slot = "Hands", diff = 2, cat = "DUNGEON", cost = "Free", where = "Lower Blackrock Spire, Overlord Wyrmthalak", dungeon = "BRM", sets = { budget = true }, steps = {
    { route = "BRM" },
    { text = "Go UP to the Blackrock Spire portal. Lower Blackrock Spire needs no key. Kill Overlord Wyrmthalak (last boss, about 20%) and roll Need." },
  }},
  { name = "Ornate Adamantium Breastplate", slot = "Chest", diff = 2, cat = "QUEST", cost = "Free", where = "Tirion Fordring quest chain (In Dreams)", sets = { budget = true }, steps = {
    { text = "Go to Tirion Fordring's hut on the west edge of Eastern Plaguelands.", wp = { "Eastern Plaguelands", 5.2, 35.6 }, auto = true },
    { text = "Do \"Demon Dogs\", then \"Redemption\", \"Of Forgotten Memories\" and \"Of Lost Honor\" (follow the quest text)." },
    { text = "\"Of Love and Family\" (2 parts): one part needs a painting from inside Stratholme. Do it on a Strat run." },
    { text = "Find Myranda the Hag in Western Plaguelands, then do \"Scarlet Subterfuge\".", wp = { "Western Plaguelands", 50.8, 77.8 }, auto = true },
    { text = "\"In Dreams\" (elite): escort Taelan Fordring out of Hearthglen. Bring 2-4 people. Turn in and pick Ornate Adamantium Breastplate." },
  }},
  { name = "Helm of the Executioner", slot = "Head", diff = 3, cat = "DUNGEON", cost = "Free", where = "Stratholme (Undead side), Baron Rivendare", dungeon = "STRAT", sets = { budget = true }, steps = {
    { route = "STRAT" },
    { text = "Clear the Undead side to Baron Rivendare (last boss, about 20%) and roll Need. Grab the Tirion painting on the same trip if you need it." },
  }},
  { name = "Battleborn Armbraces", slot = "Wrist", diff = 3, cat = "DUNGEON", cost = "Free", where = "Upper Blackrock Spire, Warchief Rend Blackhand", dungeon = "BRM", sets = { budget = true }, steps = {
    { text = "Someone in your group needs the Seal of Ascension (UBRS key, quest from Vaelan in Lower Blackrock Spire)." },
    { route = "BRM" },
    { text = "Go UP into Upper Blackrock Spire. Kill Warchief Rend Blackhand after the arena event (about 20%). Drakkisath (shield) and Goraluk (legs) are in the same run." },
  }},
  { name = "Draconian Deflector", slot = "Off hand", diff = 3, cat = "DUNGEON", cost = "Free", where = "Upper Blackrock Spire, General Drakkisath", dungeon = "BRM", sets = { budget = true }, steps = {
    { text = "Someone in your group needs the Seal of Ascension (UBRS key)." },
    { route = "BRM" },
    { text = "Clear Upper Blackrock Spire to General Drakkisath (last boss, about 25%) and roll Need." },
  }},
}


-- Tier 0.5: Deliana (Ironforge) / Mokvar (Orgrimmar) swap Valor pieces for Heroism boxes
local T05 = {
  [1] = { diff = 2, quest = "Just Compensation (step 1)", give = "Belt of Valor + Gauntlets of Valor",
    boxT = "Immoveable Gloves and Belt Set (tank: Handguards + Waistguard)", boxD = "Unstoppable Gloves and Belt Set (DPS: Gauntlets + Belt)",
    how = "It's the first quest of the chain." },
  [2] = { diff = 3, quest = "Anthion's Parting Words (step 10)", give = "Boots + Legplates + Spaulders of Valor",
    boxT = "Immoveable Boots, Legs and Shoulders Set (tank: Sabatons + Legguards + Pauldrons)", boxD = "Unstoppable Boots, Legs and Shoulders Set (DPS)",
    how = "Steps 2-9 first: Anthion's ghost at Stratholme, rescue Ysida from Baron Rivendare, Anthion's materials, Falrin in Dire Maul (25 Ogre Warbeads + enchantment), then the Ring of the Law challenge in Blackrock Depths." },
  [3] = { diff = 4, quest = "Saving the Best for Last (final step)", give = "Helm of Valor + Breastplate of Valor",
    boxT = "Immoveable Helm and Chestpiece Set (tank: Faceguard + Chestguard)", boxD = "Unstoppable Helm and Chestpiece Set (DPS: Crown + Breastplate)",
    how = "Steps 11-19 first: Bodley in Blackrock Mountain, Three Kings of Flame, Mor Grayhoof, Bloodkelp on Alcaz Island, Isalien, then summon and kill Lord Valthalak in Upper Blackrock Spire." },
}
local function hero(name, slot, price, stage, which)
  if stage == 0 then
    return { name = name, slot = slot, diff = 2, cat = "TIER", cost = "~" .. price, where = "Sold by Deliana / Mokvar (Tier 0.5 vendor)", steps = {
      { text = "Go to Deliana (The High Seat, Ironforge) or Mokvar (Grommash Hold, Orgrimmar)." },
      { text = "Buy " .. name .. " for about " .. price .. ". No turn-in box has bracers, so the vendor is the only listed source. It may need part of the Tier 0.5 chain done first." },
    } }
  end
  local st = T05[stage]
  return { name = name, slot = slot, diff = st.diff, cat = "TIER", cost = "Valor pieces", where = "Tier 0.5 chain: " .. st.quest, steps = {
    { text = "Collect the Valor (Tier 0) pieces you hand in: " .. st.give .. "." },
    { text = "Start / continue the Tier 0.5 chain with Deliana (Ironforge) or Mokvar (Orgrimmar). " .. st.how },
    { text = "Turn in \"" .. st.quest .. "\" and pick the " .. (which == "T" and st.boxT or st.boxD) .. ". Right-click the box to open it." },
    { text = "Want another version too? Deliana / Mokvar also sell every Heroism version for gold (about " .. price .. " for this one)." },
  } }
end
for _, h in ipairs({
  { "Pauldrons of Heroism", "Shoulder", "25g", 2, "T" }, { "Wristguards of Heroism", "Wrist", "25g", 0 },
  { "Handguards of Heroism", "Hands", "50g", 1, "T" }, { "Breastplate of Heroism", "Chest", "100g", 3, "D" },
  { "Gauntlets of Heroism", "Hands", "50g", 1, "D" }, { "Faceguard of Heroism", "Head", "100g", 3, "T" },
  { "Waistguard of Heroism", "Waist", "25g", 1, "T" }, { "Legguards of Heroism", "Legs", "50g", 2, "T" },
  { "Bracers of Heroism", "Wrist", "25g", 0 },
}) do ITEMS[#ITEMS + 1] = hero(h[1], h[2], h[3], h[4], h[5]) end

-- Wowhead list items
for _, it in ipairs({
  { name = "Howler's Furs", slot = "Back", diff = 1, cat = "PIX", cost = "75 Reals", where = "Pix Xizzix, Booty Bay", steps = {
    { text = "Collect 75 Reals. " .. PIX_REALS }, { route = "BOOTY" }, { text = "Buy Howler's Furs (75 Reals) from Pix Xizzix." } } },
  { name = "Girdle of Extracted Answers", slot = "Waist", diff = 2, cat = "DUNGEON", cost = "Free", where = "Alcaz Prison, The Questioner", dungeon = "ALCAZ", steps = {
    { route = "ALCAZ" }, { text = "Kill The Questioner (about 30%) and roll Need." } } },
  { name = "Heart of Wyrmthalak", slot = "Trinket", diff = 2, cat = "DUNGEON", cost = "Free", where = "Lower Blackrock Spire, Overlord Wyrmthalak", dungeon = "BRM", steps = {
    { route = "BRM" }, { text = "Go UP into Lower Blackrock Spire (no key). Kill Overlord Wyrmthalak (about 15%)." } } },
  { name = "Grimy Metal Boots", slot = "Feet", diff = 2, cat = "DUNGEON", cost = "Free", where = "Dire Maul North, King Gordok", dungeon = "DM", steps = {
    { text = "You need the Crescent Key for Dire Maul North (from Pusillin in Dire Maul East)." },
    { route = "DM" }, { text = "Enter NORTH (Gordok Commons) and kill King Gordok (about 24%)." } } },
  { name = "Ouroboros Ring", slot = "Ring", diff = 2, cat = "QUEST", cost = "Free", where = "Blackmaw Hold quest: Blackmaw Reclamation", dungeon = "BMH", steps = {
    { route = "BMH" }, { text = "Do the Blackmaw quests, then \"Blackmaw Reclamation\": defeat Varrox Bleakhoof. Pick Ouroboros Ring." } } },
  { name = "Venomvessel Ring", slot = "Ring", diff = 2, cat = "DUNGEON", cost = "Free", where = "Shaper's Terrace (Un'Goro), Venomridge", dungeon = "SHAPER", steps = {
    { route = "SHAPER" },
    { text = "Kill Venomridge, an elite beast inside (about 34%), and roll Need. Alliance: take \"Panic at the Digsite\" first, it asks you to kill Venomridge too." } } },
  { name = "Iceblade Hacker", slot = "Main hand", diff = 3, cat = "DUNGEON", cost = "Free", where = "Scholomance, Ras Frostwhisper", dungeon = "SCHOLO", steps = {
    { route = "SCHOLO" }, { text = "Kill Ras Frostwhisper (about 16%). He also drops the Intricately Runed Shield." } } },
  { name = "Intricately Runed Shield", slot = "Off hand", diff = 3, cat = "DUNGEON", cost = "Free", where = "Scholomance, Ras Frostwhisper", dungeon = "SCHOLO", steps = {
    { route = "SCHOLO" }, { text = "Kill Ras Frostwhisper (about 16%) and roll Need." } } },
  { name = "Persuader", slot = "Main hand", diff = 3, cat = "AH", cost = "Expensive", where = "Blacksmithing craft", steps = {
    { text = "Persuader is a Blacksmithing epic mace. Ask in Trade for a crafter, or check the Auction House." } } },
  { name = "Beads of Ogre Might", slot = "Neck", diff = 3, cat = "QUEST", cost = "Free", where = "Tier 0.5 chain: Falrin's Vendetta", steps = {
    { text = "Start the Tier 0.5 chain with Deliana (Ironforge) or Mokvar (Orgrimmar): Just Compensation." },
    { text = "In Search of Anthion -> Dead Man's Plea (Stratholme) -> Proof of Life -> Anthion's Strange Request -> Anthion's Old Friend." },
    { text = "Falrin's Vendetta: 25 Ogre Warbeads from ogres in Dire Maul or Blackrock Spire, to Falrin Treeshaper in the Athenaeum (Dire Maul West). Pick Beads of Ogre Might." } } },
  { name = "Amulet of the Darkmoon", slot = "Neck", diff = 4, cat = "VENDOR", cost = "1200 tickets", where = "Darkmoon Faire, Gelvas Grimegate", steps = {
    { text = "Wait for the Darkmoon Faire (Elwynn Forest or Mulgore)." },
    { text = "Collect 1,200 Darkmoon Prize Tickets from Faire turn-ins, then buy it from Gelvas Grimegate." } } },
  { name = "Blackskull Shield", slot = "Off hand", diff = 4, cat = "AH", cost = "AH price", where = "Very rare world drop (Bind on Equip)", steps = {
    { text = "Check the Auction House. It's a very rare world drop, so buying is the only sensible way." } } },
}) do ITEMS[#ITEMS + 1] = it end

-- ===== Build items and sets for every class/spec from GourtsGearingData =====
-- Hand-written items above (prot warrior) keep their detailed steps; everything
-- else is generated from Wowhead gear lists + ForeverDB/endgametools sources.
local HAND = {}
for _, it in ipairs(ITEMS) do HAND[it.name] = it end
local GD = GourtsGearingData or { specs = {}, items = {} }
local ITEM_IDS, EPIC, ID_INDEX = {}, {}, {}
local SPECS = GD.specs
local SET_NAMES, SET_SPEC, SET_POS, SPEC_BY_KEY = {}, {}, {}, {}
local SET_BASE = {}
local SET_ORDER = {}

local function genSteps(g)
  local out, usedRoute = {}, false
  for _, s in ipairs(g.steps or {}) do
    if s.route and ROUTES[s.route] and not usedRoute and s.h == "Travel" then
      out[#out + 1] = { route = s.route }
      usedRoute = true
    elseif s.wpA then
      out[#out + 1] = { text = s.h .. ": " .. s.t, wp = s.wpA, faction = "Alliance", auto = true }
      out[#out + 1] = { text = s.h .. ": " .. s.t, wp = s.wpH, faction = "Horde", auto = true }
    else
      if s.route and ROUTES[s.route] and not usedRoute then
        out[#out + 1] = { route = s.route }
        usedRoute = true
      end
      out[#out + 1] = { text = s.h .. ": " .. s.t, wp = s.wp, auto = s.wp and true or nil }
    end
  end
  if #out == 0 then out[1] = { text = "No steps yet. Check the item on Wowhead." } end
  return out
end

local ids = {}
for id in pairs(GD.items) do ids[#ids + 1] = id end
table.sort(ids)
local NEWITEMS = {}
for _, id in ipairs(ids) do
  local g = GD.items[id]
  local h = HAND[g.name]
  local it
  if h then
    it = {}
    for k, v in pairs(h) do it[k] = v end
    if g.cat == "TIER" and g.steps[1] and g.steps[1].h:find("^Collect") and it.steps and it.steps[1] and it.steps[1].text and it.steps[1].text:find("^Collect") then
      local st = {}
      for k2, v2 in ipairs(it.steps) do st[k2] = v2 end
      st[1] = { text = g.steps[1].h .. ": " .. g.steps[1].t }
      it.steps = st
    end
  else
    it = { name = g.name, diff = g.diff, cat = g.cat, cost = g.cost, where = g.where, dungeon = g.route, steps = genSteps(g), tip = g.tip }
  end
  it.id, it.slot, it.q, it.group, it.sets = id, g.slot, g.q, g.group, {}
  it.mats, it.boe = g.mats, g.boe
  NEWITEMS[#NEWITEMS + 1] = it
  ID_INDEX[id] = #NEWITEMS
  ITEM_IDS[g.name] = id
  if (g.q or 3) >= 4 then EPIC[g.name] = true end
end
ITEMS = NEWITEMS

for _, sp in ipairs(SPECS) do
  SPEC_BY_KEY[sp.key] = sp
  for _, st in ipairs(sp.sets) do
    st.alts = st.alts or {}
    SET_NAMES[st.key] = st.name
    SET_SPEC[st.key] = sp.key
    SET_POS[st.key] = {}
    SET_BASE[st.key] = {}
    for pos, id in ipairs(st.items) do
      local idx = ID_INDEX[id]
      if idx then ITEMS[idx].sets[st.key] = true; SET_POS[st.key][idx] = pos; SET_BASE[st.key][pos] = idx end
    end
  end
end

-- items people swap in that the guide doesn't know get a simple entry
local function customItem(id, slot)
  if ID_INDEX[id] then return ID_INDEX[id] end
  local name = (GetItemInfo and GetItemInfo(id)) or ("Item " .. id)
  local _, _, q = GetItemInfo and GetItemInfo(id)
  local it = { id = id, name = name, slot = slot, q = q or 3, diff = 3, cat = "CUSTOM", cost = "?", where = "Your own pick", sets = {}, custom = true,
    steps = { { text = "Your own pick. There is no guide for this item yet: look it up on Wowhead or ForeverDB (item " .. id .. ") for where it comes from." } } }
  ITEMS[#ITEMS + 1] = it
  ID_INDEX[id] = #ITEMS
  ITEM_IDS[name] = id
  return #ITEMS
end
-- rebuild one set's membership from its original list + the player's swaps
local function applyCustom(key, custom)
  local base = SET_BASE[key]
  if not base then return end
  for idx in pairs(SET_POS[key]) do ITEMS[idx].sets[key] = nil end
  wipe(SET_POS[key])
  local ov = (custom and custom[key]) or {}
  for pos, idx in pairs(base) do
    local use = idx
    if ov[pos] then use = customItem(ov[pos], ITEMS[idx].slot) end
    ITEMS[use].sets[key] = true
    SET_POS[key][use] = pos
  end
end

local CLASS_NAMES = { warrior = "Warrior", paladin = "Paladin", hunter = "Hunter", rogue = "Rogue", priest = "Priest",
  shaman = "Shaman", mage = "Mage", warlock = "Warlock", druid = "Druid" }
local CLASS_ORDER = { "warrior", "paladin", "hunter", "rogue", "priest", "shaman", "mage", "warlock", "druid" }
local CLASS_COLORS = { warrior = "ffc79c6e", paladin = "fff58cba", hunter = "ffabd473", rogue = "fffff569", priest = "ffffffff",
  shaman = "ff2e8bff", mage = "ff40c7eb", warlock = "ff9482c9", druid = "ffff7d0a" }

local function specLabel(specKey)
  local sp = SPEC_BY_KEY[specKey]
  if not sp then return "?" end
  return CLASS_NAMES[sp.cls] .. " " .. sp.spec
end
-- short tag used on tooltips: "Prot: Balanced"
local function shortSet(key)
  local sp = SPEC_BY_KEY[SET_SPEC[key]]
  local s = sp and sp.spec or ""
  s = s:gsub("Protection", "Prot"):gsub("Restoration", "Resto"):gsub("Retribution", "Ret"):gsub("Beast Mastery", "BM")
       :gsub("Marksmanship", "MM"):gsub("Assassination", "Assa"):gsub("Destruction", "Destro"):gsub("Demonology", "Demo")
       :gsub("Affliction", "Affli"):gsub("Enhancement", "Enh"):gsub("Elemental", "Ele"):gsub("Discipline", "Disc"):gsub("Subtlety", "Sub")
  return s .. ": " .. (SET_NAMES[key] or "?")
end
-- refresh SET_ORDER to the current spec's sets
local function loadSpecSets(specKey)
  wipe(SET_ORDER)
  local sp = SPEC_BY_KEY[specKey]
  if sp then for _, st in ipairs(sp.sets) do SET_ORDER[#SET_ORDER + 1] = st.key end end
end
local function defaultSpecFor(cls)
  for _, sp in ipairs(SPECS) do if sp.cls == cls and #sp.sets > 0 then return sp.key end end
  return "warrior/protection"
end


local DIFF = { "|cff3ddc3dEasy (even Raze can)|r", "|cffffd200Medium (Gourt tier)|r", "|cffff8c33Hard (Big Gourt tier)|r", "|cffff4040Very hard (pray to Gourt)|r", "|cff999999Unconfirmed (Gourt knows not)|r" }
local CATS = {
  { key = "ALL", name = "All, easiest first" },
  { key = "PIX", name = "Booty Bay vendor" },
  { key = "DUNGEON", name = "Dungeon drops" },
  { key = "QUEST", name = "Quest rewards" },
  { key = "PVP", name = "PvP reputation" },
  { key = "AH", name = "Auction House / craft" },
  { key = "UNKNOWN", name = "Not confirmed" },
  { key = "ROUTES", name = "Take me to..." },
}
local ROUTE_ORDER = { "DM", "BRM", "STRAT", "SCHOLO", "SHAPER", "MARA", "KROL", "BMH", "ALCAZ", "BOOTY", "AV" }
local ROUTE_SHORT = { DM = "Dire Maul", BRM = "Blackrock Mt.", STRAT = "Stratholme", SCHOLO = "Scholomance", MARA = "Maraudon", KROL = "Krol'dok", BMH = "Blackmaw Hold", SHAPER = "Shaper's Terrace", ALCAZ = "Alcaz Prison", BOOTY = "Booty Bay", AV = "AV vendor" }

------------------------------------------------------------------------
-- State helpers
------------------------------------------------------------------------
local db
local faction
local setOrder

-- item indexes in the current set, easiest first; NUM[i] = position
local NUM = {}
setOrder = function()
  local set = (db and db.set) or ""
  local out = {}
  for i, it in ipairs(ITEMS) do if it.sets[set] then out[#out + 1] = i end end
  local pos = SET_POS[set] or {}
  table.sort(out, function(a, b)
    if ITEMS[a].diff ~= ITEMS[b].diff then return ITEMS[a].diff < ITEMS[b].diff end
    return (pos[a] or a) < (pos[b] or b)
  end)
  wipe(NUM)
  for pos, i in ipairs(out) do NUM[i] = pos end
  return out
end

local function expand(steps)
  local out = {}
  for _, s in ipairs(steps) do
    if s.route then
      for _, leg in ipairs(ROUTES[s.route].legs) do
        if not leg.faction or leg.faction == faction then
          out[#out + 1] = { text = leg.text, wp = leg.wp, auto = leg.wp and true or nil }
        end
      end
    elseif not s.faction or s.faction == faction then
      out[#out + 1] = s
    end
  end
  return out
end

-- the guide currently followed by the arrow
local function activeSteps()
  local g = db.guide
  if not g then return nil end
  if g.kind == "item" then
    local it = ITEMS[g.key]
    return it and expand(it.steps), it and it.name
  else
    local r = ROUTES[g.key]
    return r and expand({ { route = g.key } }), r and ("Route: " .. r.name)
  end
end

------------------------------------------------------------------------
-- Map math
------------------------------------------------------------------------
local mapCache = {}
local function zoneMapID(name, mapType)
  mapType = mapType or 3
  local ck = name .. "#" .. mapType
  if mapCache[ck] ~= nil then return mapCache[ck] or nil end
  local found = false
  if C_Map and C_Map.GetMapInfo then
    for id = 1, 3000 do
      local info = C_Map.GetMapInfo(id)
      if info and info.name == name and info.mapType == mapType then found = id break end
    end
  end
  mapCache[ck] = found
  return found or nil
end

local function worldPos(mapID, x, y)
  if not (C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return end
  local cont, pos = C_Map.GetWorldPosFromMapPos(mapID, CreateVector2D(x, y))
  if not pos then return end
  local north, west = pos:GetXY()
  return cont, north, west
end

local function playerWorld()
  if not (C_Map and C_Map.GetBestMapForUnit) then return end
  local mapID = C_Map.GetBestMapForUnit("player")
  if not mapID then return end
  local p = C_Map.GetPlayerMapPosition(mapID, "player")
  if not p then return end
  local x, y = p:GetXY()
  return worldPos(mapID, x, y)
end

local BACKDROP = {
  bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
  edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
  tile = true, tileSize = 16, edgeSize = 14,
  insets = { left = 3, right = 3, top = 3, bottom = 3 },
}
local function skin(frame, alpha)
  if frame.SetBackdrop then
    frame:SetBackdrop(BACKDROP)
    frame:SetBackdropColor(0.07, 0.04, 0.12, alpha or 0.92)
    frame:SetBackdropBorderColor(0.64, 0.21, 0.93, 1)
  end
end
local function newFrame(name, parent)
  return CreateFrame("Frame", name, parent or UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
end
local function makeMovable(frame, key)
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:SetClampedToScreen(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", frame.StartMoving)
  frame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p, _, rp, x, y = self:GetPoint()
    db[key] = { p, rp, x, y }
  end)
end
local function button(parent, label, w, h)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w, h or 22)
  b:SetText(label)
  return b
end

------------------------------------------------------------------------
-- The Gourt Zone (memes)
------------------------------------------------------------------------
local QUOTES = {
  "Big Gourt doesn't farm drops. Drops farm Big Gourt.",
  "If lost, ask Gourt. If still lost, ask Big Gourt.",
  "Raze says the drop rate is 100%. Raze is lying.",
  "Somewhere, right now, Raze is standing in the fire.",
  "This route is officially Big Gourt approved.",
  "Gourt's rule #1: Need on anything with Stamina.",
  "Raze pulled the next pack. Of course Raze did.",
  "Every Real you farm makes Gourt a little bigger.",
  "Big Gourt's hearthstone is always on cooldown. Always.",
  "Raze rolled Need on your shield again. Classic Raze.",
  "A true Gourt never AFKs on the flight path.",
  "Gourt tanked UBRS in greens. You have no excuse.",
  "Raze would've used a speed potion by now.",
  "Behind every Big Gourt is a smaller Gourt farming Reals.",
  "Raze said 'one more run' four hours ago.",
  "Gourt doesn't wipe. The raid just lies down near Gourt.",
  "Big Gourt was here. The bosses remember.",
  "Raze is 'just grabbing a drink'. Raze is gone for 20 minutes.",
}
local HYPE = {
  "BIG GOURT ENERGY", "GOURTED IT", "RAZE IS JEALOUS", "LOOT GOBLIN GOURT",
  "GOURT GOT GEAR", "ABSOLUTE GOURT", "RAZE COULD NEVER", "+1 GOURT",
}
local ARRIVE = {
  "You're here! Gourt is proud.", "Arrived. Raze is still lost.", "Here! Big Gourt nods.",
  "Made it. Raze took the scenic route.", "You're here. Very Gourt of you.",
}
local FAR = {
  { 3000, "Raze says it's close. It's not." },
  { 1500, "Gourt's still on the flight path" },
  { 600, "keep running, Gourt" },
}
local RANKS = {
  { 0, "Tiny Gourt" }, { 0.01, "Smol Gourt" }, { 0.25, "Gourt" }, { 0.5, "Medium Gourt" },
  { 0.75, "Large Gourt" }, { 0.9, "Almost Big Gourt" }, { 1, "BIG GOURT" },
}
local DIFF_MEME = { "Even Raze can", "Gourt tier", "Big Gourt tier", "Pray to Gourt", "Gourt knows not" }

local function pick(t) return t[math.random(#t)] end

-- meme pictures shipped in GourtsGearing\img (w/h = the original picture's shape)
local PICS = {
  { file = "congrats", w = 1347, h = 1861 },
  { file = "cat", w = 1024, h = 1536 },
  { file = "shock", w = 115, h = 120 },
  { file = "face", w = 100, h = 85 },
  { file = "bed", w = 951, h = 529 },
  { file = "giraffe", w = 45, h = 68 },
}
-- surprise memes: only shown when you loot a new piece of your set
local LOOT_PICS = {
  { file = "duck", w = 1152, h = 800 },
  { file = "light", w = 526, h = 526 },
  { file = "patrick", w = 310, h = 200 },
  { file = "cheese", w = 339, h = 262 },
  { file = "flextape", w = 500, h = 560 },
  { file = "wipefactory", w = 1080, h = 1095 },
  { file = "doodlie", w = 1729, h = 871 },
  { file = "goblin", w = 421, h = 586 },
  { file = "mooove", w = 652, h = 372 },
  { file = "holycow", w = 660, h = 403 },
  { file = "abom", w = 1920, h = 1080 },
}
local function picPath(pc) return "Interface\\AddOns\\GourtsGearing\\img\\" .. pc.file end
-- show picture pc on texture tex, fitted inside a maxW x maxH box
local function showPic(tex, pc, maxW, maxH)
  local sc = math.min(maxW / pc.w, maxH / pc.h)
  tex:SetTexture(picPath(pc))
  tex:SetSize(pc.w * sc, pc.h * sc)
end
local function rankFor(frac)
  local r = RANKS[1][2]
  for _, v in ipairs(RANKS) do if frac >= v[1] then r = v[2] end end
  return r
end

-- Big splash in the middle of the screen
local SP = CreateFrame("Frame", "GearPathSplash", UIParent)
SP:SetSize(600, 200)
SP:SetPoint("CENTER", UIParent, "CENTER", 0, 160)
SP:SetFrameStrata("FULLSCREEN_DIALOG")
SP:Hide()
local spHead = SP:CreateFontString(nil, "OVERLAY")
spHead:SetFont("Fonts\\SKURRI.TTF", 52, "THICKOUTLINE")
spHead:SetPoint("CENTER", 0, 20)
spHead:SetTextColor(1, 0.82, 0.1)
spHead:SetShadowOffset(4, -4)
spHead:SetShadowColor(0, 0, 0, 1)
local spSub = SP:CreateFontString(nil, "OVERLAY")
spSub:SetFont("Fonts\\FRIZQT__.TTF", 20, "OUTLINE")
spSub:SetPoint("TOP", spHead, "BOTTOM", 0, -10)
spSub:SetTextColor(0.85, 0.65, 1)
local spPic = SP:CreateTexture(nil, "ARTWORK")
spPic:SetPoint("BOTTOM", spHead, "TOP", 0, 10)
local skulls = {}
for i, side in ipairs({ "LEFT", "RIGHT" }) do
  local t = SP:CreateTexture(nil, "ARTWORK")
  t:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_8")
  t:SetSize(56, 56)
  t:SetPoint(side == "LEFT" and "RIGHT" or "LEFT", spHead, side, side == "LEFT" and -14 or 14, 0)
  skulls[i] = t
end
local spT = 0
SP:SetScript("OnUpdate", function(self, e)
  spT = spT + e
  local s = spT < 0.25 and (0.4 + 2.8 * spT) or (spT < 0.4 and (1.1 - (spT - 0.25)) or 1)
  self:SetScale(math.max(0.3, s))
  self:SetAlpha(spT > 2.6 and math.max(0, 1 - (spT - 2.6) / 0.6) or 1)
  skulls[1]:SetRotation(spT * 3)
  skulls[2]:SetRotation(-spT * 3)
  local pulse = 0.8 + 0.2 * math.sin(spT * 12)
  spHead:SetTextColor(1, 0.6 + 0.3 * pulse, 0.1)
  if spT > 3.2 then self:Hide() end
end)
local function splash(head, sub, pc)
  spT = 0
  showPic(spPic, pc or pick(LOOT_PICS), 220, 170)
  spHead:SetText(head)
  spSub:SetText(sub or "")
  SP:SetScale(0.4); SP:SetAlpha(1); SP:Show()
  if NS.playSound then NS.playSound()
  else
    local snd = SOUNDKIT and (SOUNDKIT.RAID_WARNING or SOUNDKIT.READY_CHECK)
    if PlaySound and snd then PlaySound(snd) end
  end
end

------------------------------------------------------------------------
-- Arrow window
------------------------------------------------------------------------
local A = newFrame("GearPathFrame")
A:SetSize(300, 214)
A:SetPoint("CENTER", UIParent, "CENTER", 0, 180)
skin(A, 0.88)
A:Hide()

local aTitle = A:CreateFontString(nil, "OVERLAY", "GameFontNormal")
aTitle:SetPoint("TOPLEFT", 12, -10)
aTitle:SetPoint("TOPRIGHT", -30, -10)
aTitle:SetJustifyH("LEFT")
local aClose = CreateFrame("Button", nil, A, "UIPanelCloseButton")
aClose:SetPoint("TOPRIGHT", 2, 2)
local aSub = A:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
aSub:SetPoint("TOPLEFT", aTitle, "BOTTOMLEFT", 0, -3)
aSub:SetTextColor(0.75, 0.68, 0.85)

local arrow = A:CreateTexture(nil, "ARTWORK")
arrow:SetTexture("Interface\\Minimap\\MinimapArrow")
arrow:SetSize(64, 64)
arrow:SetPoint("TOPLEFT", 10, -44)
local dist = A:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
dist:SetPoint("TOP", arrow, "BOTTOM", 0, 2)
dist:SetWidth(90)
dist:SetFont("Fonts\\FRIZQT__.TTF", 11)

local body = A:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
body:SetPoint("TOPLEFT", 90, -46)
body:SetPoint("RIGHT", -12, 0)
body:SetHeight(118)
body:SetJustifyH("LEFT")
body:SetJustifyV("TOP")
body:SetWordWrap(true)

local bMenu = button(A, "Menu", 50); bMenu:SetPoint("BOTTOMLEFT", 10, 10)
local bBack = button(A, "< Back", 60); bBack:SetPoint("LEFT", bMenu, "RIGHT", 4, 0)
local bNext = button(A, "Next >", 60); bNext:SetPoint("LEFT", bBack, "RIGHT", 4, 0)
local bGot  = button(A, "Got it!", 98); bGot:SetPoint("LEFT", bNext, "RIGHT", 4, 0)

local current, arrivedAt
local refreshMenu -- defined later
local setBtns

local function refreshArrow()
  local steps, name = activeSteps()
  arrivedAt = nil
  if not steps then
    aTitle:SetText("Gourt's Gearing")
    aSub:SetText("")
    body:SetText("Nothing selected. Click Menu to pick an item or a place.")
    current = nil
    bBack:SetEnabled(false); bNext:SetEnabled(false); bGot:Hide()
    return
  end
  db.step = math.max(1, math.min(db.step or 1, #steps))
  current = steps[db.step]
  local isItem = db.guide.kind == "item"
  local done = isItem and db.done[name]
  if isItem then setOrder() end
  local num = isItem and NUM[db.guide.key] and ("#" .. NUM[db.guide.key] .. "  ") or ""
  aTitle:SetText(num .. name .. (done and "  |cff3ddc3d(got it)|r" or ""))
  aSub:SetText(("Step %d of %d"):format(db.step, #steps))
  local zone = current.wp and ("|cff7dbdff%s %.1f, %.1f%s|r\n"):format(current.wp[1], current.wp[2], current.wp[3], current.wp.approx and " (approx.)" or "") or ""
  body:SetText(zone .. current.text)
  bBack:SetEnabled(db.step > 1)
  bNext:SetEnabled(db.step < #steps)
  if isItem then bGot:Show(); bGot:SetText(done and "Not got yet" or "Got it!") else bGot:Hide() end
end

bMenu:SetScript("OnClick", function() GearPathMenu:Show() end)
bBack:SetScript("OnClick", function() db.step = db.step - 1; refreshArrow() end)
bNext:SetScript("OnClick", function() db.step = db.step + 1; refreshArrow() end)
bGot:SetScript("OnClick", function()
  local it = ITEMS[db.guide.key]
  if db.done[it.name] then
    db.done[it.name] = nil
  else
    db.done[it.name] = true
    celebrate(it)
  end
  refreshArrow()
  if refreshMenu then refreshMenu() end
end)

local function celebrate(it)
  local order, got = setOrder(), 0
  for _, i in ipairs(order) do if db.done[ITEMS[i].name] then got = got + 1 end end
  if got == #order then
    splash("BIG GOURT ACHIEVED", "Full " .. SET_NAMES[db.set or "bis"] .. " collected. Raze is in shambles.", PICS[1])
  else
    splash(pick(HYPE), "+1 " .. it.name .. "   (" .. got .. "/" .. #order .. ", rank: " .. rankFor(got / #order) .. ")")
  end
  print("|cffc07cffGourt's Gearing:|r got " .. it.name .. "! " .. pick(QUOTES))
end

local elapsed = 0
A:SetScript("OnUpdate", function(_, e)
  elapsed = elapsed + e
  if elapsed < 0.05 then return end
  local dt = elapsed
  elapsed = 0
  local wp = current and current.wp
  if not wp then
    arrow:Hide()
    dist:SetText(current and "|cffaaaaaafollow the text|r" or "")
    return
  end
  local tid = zoneMapID(wp[1], wp.continent and 2 or 3)
  local tc, tn, tw
  if tid then tc, tn, tw = worldPos(tid, wp[2] / 100, wp[3] / 100) end
  local pc, pn, pw = playerWorld()
  local facing = GetPlayerFacing and GetPlayerFacing()
  if not (tc and pc and facing) then
    arrow:Hide()
    dist:SetText(pc and "|cffaaaaaano arrow here|r" or "|cffaaaaaano position|r")
    return
  end
  if tc ~= pc then
    arrow:Hide()
    dist:SetText("|cffffc25aother continent|r")
    return
  end
  local dn, dw = tn - pn, tw - pw
  local yards = math.sqrt(dn * dn + dw * dw)
  arrow:Show()
  if yards <= (wp.approx and 60 or 12) then
    arrow:SetVertexColor(0.24, 0.86, 0.24)
    arrow:SetRotation(0)
    if not current.quip then current.quip = pick(ARRIVE) end
    dist:SetText("|cff3ddc3d" .. current.quip .. "|r")
    if current.auto then
      arrivedAt = (arrivedAt or 0) + dt
      local steps = activeSteps()
      if arrivedAt > 1.5 and steps and db.step < #steps then
        db.step = db.step + 1
        if PlaySound and SOUNDKIT and SOUNDKIT.MAP_PING then PlaySound(SOUNDKIT.MAP_PING) end
        refreshArrow()
      end
    end
  else
    arrivedAt = nil
    arrow:SetRotation(math.atan2(dw, dn) - facing)
    local t = math.min(yards / 500, 1)
    arrow:SetVertexColor(0.3 + 0.7 * t, 1 - 0.5 * t, 0.3)
    local q = ""
    for _, f in ipairs(FAR) do if yards >= f[1] then q = "\n|cffaaaaaa" .. f[2] .. "|r" break end end
    dist:SetText(("%d yd"):format(math.floor(yards + 0.5)) .. q)
  end
end)

local function startGuide(kind, key)
  db.guide = { kind = kind, key = key }
  db.step = 1
  refreshArrow()
  A:Show()
end

------------------------------------------------------------------------
-- Menu window: character-sheet style
------------------------------------------------------------------------
local function itemIcon(id)
  local tex
  if C_Item and C_Item.GetItemIconByID then tex = C_Item.GetItemIconByID(id) end
  if not tex and GetItemIcon then tex = GetItemIcon(id) end
  return tex or "Interface\\Icons\\INV_Misc_QuestionMark"
end

local M = newFrame("GearPathMenu")
M:SetSize(760, 520)
M:SetPoint("CENTER")
M:SetFrameStrata("HIGH")
skin(M, 0.96)
M:Hide()
tinsert(UISpecialFrames, "GearPathMenu")

local mTitle = M:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
mTitle:SetPoint("TOPLEFT", 14, -12)
mTitle:SetText("Gourt's Gearing")
local mProg = M:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
mProg:SetPoint("LEFT", mTitle, "RIGHT", 12, 0)
local mClose = CreateFrame("Button", nil, M, "UIPanelCloseButton")
mClose:SetPoint("TOPRIGHT", 2, 2)
local selectFirstOpen
setBtns = {}
local setMain = button(M, "Set", 220, 22); setMain:SetPoint("TOPRIGHT", -34, -10)
local setPop = newFrame(nil, M)
setPop:SetWidth(262)
setPop:SetPoint("TOPRIGHT", setMain, "BOTTOMRIGHT", 4, -2)
setPop:SetFrameStrata("DIALOG")
skin(setPop, 0.98)
setPop:Hide()
local popLabel1 = setPop:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
popLabel1:SetPoint("TOPLEFT", 10, -8)
popLabel1:SetText("Class")
local classBtns, specBtns, setPool = {}, {}, {}
local browseCls
for i, c in ipairs(CLASS_ORDER) do
  local b = button(setPop, "|c" .. CLASS_COLORS[c] .. CLASS_NAMES[c] .. "|r", 80, 20)
  b:SetPoint("TOPLEFT", 10 + ((i - 1) % 3) * 82, -22 - math.floor((i - 1) / 3) * 22)
  b.cls = c
  classBtns[i] = b
end
local popLabel2 = setPop:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
popLabel2:SetPoint("TOPLEFT", 10, -92)
popLabel2:SetText("Spec")
for i = 1, 4 do
  local b = button(setPop, "", 120, 20)
  b:SetPoint("TOPLEFT", 10 + ((i - 1) % 2) * 122, -106 - math.floor((i - 1) / 2) * 22)
  specBtns[i] = b
end
local popLabel3 = setPop:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
popLabel3:SetPoint("TOPLEFT", 10, -156)
popLabel3:SetText("Gear set")
local refreshSetPop
local function chooseSet(key)
  db.set = key
  db.spec = SET_SPEC[key] or db.spec
  loadSpecSets(db.spec)
  setPop:Hide()
  selectFirstOpen()
  refreshMenu()
  print("|cffc07cffGourt's Gearing:|r showing " .. specLabel(db.spec) .. " - " .. (SET_NAMES[key] or "?") .. ".")
end
refreshSetPop = function()
  browseCls = browseCls or (SPEC_BY_KEY[db.spec] and SPEC_BY_KEY[db.spec].cls) or "warrior"
  for _, b in ipairs(classBtns) do b:SetEnabled(b.cls ~= browseCls) end
  local n = 0
  for _, sp in ipairs(SPECS) do
    if sp.cls == browseCls then
      n = n + 1
      local b = specBtns[n]
      if b then
        b:SetText(sp.spec .. (#sp.sets == 0 and " (none)" or ""))
        b.spec = sp.key
        b:SetEnabled(sp.key ~= db.spec and #sp.sets > 0)
        b:Show()
      end
    end
  end
  for i = n + 1, #specBtns do specBtns[i]:Hide() end
  wipe(setBtns)
  for _, b in ipairs(setPool) do b:Hide() end
  for i, key in ipairs(SET_ORDER) do
    local b = setPool[i]
    if not b then
      b = button(setPop, "", 242, 22)
      b:SetPoint("TOPLEFT", 10, -170 - (i - 1) * 24)
      b:SetScript("OnClick", function(self) chooseSet(self.key) end)
      setPool[i] = b
    end
    b.key = key
    b:SetText(SET_NAMES[key])
    b:Show()
    setBtns[key] = b
  end
  setPop:SetHeight(180 + math.max(1, #SET_ORDER) * 24)
end
for _, b in ipairs(classBtns) do
  b:SetScript("OnClick", function(self) browseCls = self.cls; refreshSetPop() end)
end
for _, b in ipairs(specBtns) do
  b:SetScript("OnClick", function(self)
    db.spec = self.spec
    loadSpecSets(db.spec)
    db.set = SET_ORDER[1]
    refreshSetPop()
    selectFirstOpen()
    refreshMenu()
  end)
end
setMain:SetScript("OnClick", function()
  if setPop:IsShown() then setPop:Hide() else browseCls = nil; refreshSetPop(); setPop:Show() end
end)

local mQuote = M:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
mQuote:SetPoint("BOTTOMLEFT", 16, 14)
mQuote:SetPoint("RIGHT", -16, 0)
mQuote:SetJustifyH("LEFT")
mQuote:SetTextColor(0.85, 0.75, 1)

-- paper doll box
local doll = newFrame(nil, M)
doll:SetPoint("TOPLEFT", 12, -42)
doll:SetSize(360, 440)
if doll.SetBackdrop then
  doll:SetBackdrop(BACKDROP)
  doll:SetBackdropColor(0.02, 0.02, 0.03, 0.9)
  doll:SetBackdropBorderColor(0.45, 0.38, 0.25, 1)
end

-- the character in the middle
local model = CreateFrame("PlayerModel", nil, doll)
model:SetPoint("TOPLEFT", 64, -30)
model:SetPoint("BOTTOMRIGHT", -64, 70)
model.facing = 0
model:EnableMouse(true)
model:SetScript("OnMouseDown", function(self) self.dragX = GetCursorPosition() end)
model:SetScript("OnMouseUp", function(self) self.dragX = nil end)
model:SetScript("OnUpdate", function(self)
  if self.dragX then
    local x = GetCursorPosition()
    self.facing = self.facing + (x - self.dragX) * 0.02
    self.dragX = x
    self:SetFacing(self.facing)
  end
end)
local picBtn = CreateFrame("Button", nil, doll)
picBtn:SetPoint("TOPLEFT", 64, -30)
picBtn:SetPoint("BOTTOMRIGHT", -64, 70)
local centerPic = picBtn:CreateTexture(nil, "ARTWORK")
centerPic:SetPoint("CENTER")
local picIndex = 0
local function nextPic()
  local n
  repeat n = math.random(#PICS) until n ~= picIndex or #PICS == 1
  picIndex = n
  showPic(centerPic, PICS[n], 228, 336)
end
picBtn:SetScript("OnClick", nextPic)
picBtn:SetScript("OnEnter", function(self)
  GameTooltip:SetOwner(self, "ANCHOR_TOP")
  GameTooltip:AddLine("Click for another meme. Big Gourt insists.", 1, 0.82, 0.1)
  GameTooltip:Show()
end)
picBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
local viewBtn = CreateFrame("Button", nil, doll, "UIPanelButtonTemplate")
viewBtn:SetSize(84, 18)
viewBtn:SetPoint("TOPRIGHT", -62, -32)
viewBtn:SetFrameLevel(picBtn:GetFrameLevel() + 5)
local function applyView()
  if db.center == "model" then
    picBtn:Hide(); model:Show(); viewBtn:SetText("Show memes")
  else
    model:Hide(); picBtn:Show(); viewBtn:SetText("Show me")
  end
end
viewBtn:SetScript("OnClick", function()
  db.center = (db.center == "model") and "pic" or "model"
  applyView()
end)
local who = doll:CreateFontString(nil, "OVERLAY")
who:SetFont("Fonts\\SKURRI.TTF", 22, "OUTLINE")
who:SetPoint("TOP", 0, -8)
who:SetTextColor(1, 0.82, 0.1)
local rankLine = doll:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
rankLine:SetPoint("BOTTOM", 0, 74)

-- slots
local LEFT = { "Head", "Neck", "Shoulder", "Back", "Chest", "Wrist" }
local RIGHT = { "Hands", "Waist", "Legs", "Feet", "Ring", "Ring", "Trinket", "Trinket" }
local BOTTOM = { "Main hand", "Off hand", "Ranged" }
local slots = {}
local selected -- { kind=, key= }
local startGlow = {}

local function makeSlot(slotName, x, y)
  local b = CreateFrame("Button", nil, doll)
  b:SetSize(40, 40)
  b:SetPoint("TOPLEFT", x, y)
  b.slotName = slotName
  b.icon = b:CreateTexture(nil, "ARTWORK")
  b.icon:SetAllPoints()
  b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
  b.border = b:CreateTexture(nil, "OVERLAY")
  b.border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
  b.border:SetBlendMode("ADD")
  b.border:SetSize(72, 72)
  b.border:SetPoint("CENTER")
  b.num = b:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
  b.num:SetPoint("TOPLEFT", 2, -2)
  b.check = b:CreateTexture(nil, "OVERLAY")
  b.check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
  b.check:SetSize(26, 26)
  b.check:SetPoint("BOTTOMRIGHT", 6, -6)
  b.sel = b:CreateTexture(nil, "BACKGROUND")
  b.sel:SetColorTexture(1, 0.82, 0.1, 0.9)
  b.sel:SetPoint("TOPLEFT", -3, 3)
  b.sel:SetPoint("BOTTOMRIGHT", 3, -3)
  b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  slots[#slots + 1] = b
  return b
end
for i, s in ipairs(LEFT) do makeSlot(s, 10, -14 - (i - 1) * 48) end
for i, s in ipairs(RIGHT) do makeSlot(s, 310, -14 - (i - 1) * 48) end
for i, s in ipairs(BOTTOM) do makeSlot(s, 180 - 68 + (i - 1) * 48, -396) end

-- details (right)
local dName = M:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
dName:SetPoint("TOPLEFT", 386, -46)
dName:SetPoint("RIGHT", -14, 0)
dName:SetJustifyH("LEFT")
local dMeta = M:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
dMeta:SetPoint("TOPLEFT", dName, "BOTTOMLEFT", 0, -6)
dMeta:SetPoint("RIGHT", -14, 0)
dMeta:SetJustifyH("LEFT")

local scroll = CreateFrame("ScrollFrame", "GearPathMenuScroll", M, "UIPanelScrollFrameTemplate")
scroll:SetPoint("TOPLEFT", 386, -116)
scroll:SetPoint("BOTTOMRIGHT", -34, 190)
local child = CreateFrame("Frame", nil, scroll)
child:SetSize(330, 10)
scroll:SetScrollChild(child)
local dSteps = child:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
dSteps:SetPoint("TOPLEFT")
dSteps:SetWidth(328)
dSteps:SetJustifyH("LEFT")
dSteps:SetJustifyV("TOP")
dSteps:SetSpacing(2)

local dGo = button(M, "Guide me", 120, 26); dGo:SetPoint("BOTTOMLEFT", 386, 154)
local dGot = button(M, "Got it", 120, 26); dGot:SetPoint("LEFT", dGo, "RIGHT", 8, 0)

-- "Take me to..." places
local placeLabel = M:CreateFontString(nil, "OVERLAY", "GameFontNormal")
placeLabel:SetPoint("BOTTOMLEFT", 386, 128)
placeLabel:SetText("Take me to...")
local placeBtns = {}
for i, key in ipairs(ROUTE_ORDER) do
  local b = button(M, ROUTE_SHORT[key] or key, 116, 22)
  local col, row = (i - 1) % 3, math.floor((i - 1) / 3)
  b:SetPoint("BOTTOMLEFT", 386 + col * 120, 102 - row * 24)
  b.key = key
  placeBtns[i] = b
end

local function stepText(steps)
  local lines = {}
  for i, s in ipairs(steps) do
    local wp = s.wp and ("  |cff7dbdff(" .. s.wp[1] .. (" %.1f, %.1f)|r"):format(s.wp[2], s.wp[3])) or ""
    lines[#lines + 1] = ("|cffc07cff%d.|r %s%s"):format(i, s.text, wp)
  end
  return table.concat(lines, "\n\n")
end

local function showDetails()
  dGo:Hide(); dGot:Hide(); if GourtsGearingSwapButton then GourtsGearingSwapButton:Hide() end
  if not selected then
    dName:SetText("Click a gear slot")
    dMeta:SetText("Each slot shows the item for that slot. The number is the order to get them in, easiest first.")
    dSteps:SetText("")
    return
  end
  if selected.kind == "item" then
    local it = ITEMS[selected.key]
    local done = db.done[it.name]
    dName:SetText(("#%d  %s"):format(NUM[selected.key] or 0, it.name))
    dMeta:SetText(("%s  |  %s  |  %s\n|cffaaaaaa%s|r%s"):format(it.slot, DIFF[it.diff], it.cost, it.where,
      done and "\n|cff3ddc3dYou have this item. Very Gourt.|r" or ""))
    dSteps:SetText(stepText(expand(it.steps)))
    dGo:SetText("Guide me"); dGo:Show()
    dGot:SetText(done and "Not got yet" or "Got it"); dGot:Show()
    if GourtsGearingSwapButton then GourtsGearingSwapButton:Show() end
  else
    local r = ROUTES[selected.key]
    dName:SetText(r.name)
    local drops = {}
    for _, i in ipairs(setOrder()) do if ITEMS[i].dungeon == selected.key then drops[#drops + 1] = ITEMS[i].name end end
    dMeta:SetText("|cffaaaaaa" .. r.zone .. "|r" .. (#drops > 0 and ("\nFor: " .. table.concat(drops, ", ")) or ""))
    dSteps:SetText(stepText(expand({ { route = selected.key } })))
    dGo:SetText("Take me there"); dGo:Show()
  end
  child:SetHeight(dSteps:GetStringHeight() + 10)
  scroll:SetVerticalScroll(0)
end

-- put this set's items into the slots
local function fillSlots()
  local order = setOrder()
  local used = {}
  local nextKey
  for _, i in ipairs(order) do if not db.done[ITEMS[i].name] then nextKey = i break end end
  for _, b in ipairs(slots) do
    b.key = nil
    for _, i in ipairs(order) do
      if not used[i] and ITEMS[i].slot == b.slotName then b.key = i; used[i] = true break end
    end
    local it = b.key and ITEMS[b.key]
    if it then
      local done = db.done[it.name]
      b.icon:SetTexture(itemIcon(ITEM_IDS[it.name] or 0))
      b.icon:SetDesaturated(not done)
      b.icon:SetVertexColor(done and 1 or 0.6, done and 1 or 0.6, done and 1 or 0.6)
      if EPIC[it.name] then b.border:SetVertexColor(0.64, 0.21, 0.93) else b.border:SetVertexColor(0, 0.44, 0.87) end
      b.border:Show()
      b.num:SetText(NUM[b.key] or "")
      if done then b.check:Show() else b.check:Hide() end
      b.isNext = (b.key == nextKey)
    else
      b.icon:SetTexture("Interface\\PaperDoll\\UI-Backpack-EmptySlot")
      b.icon:SetDesaturated(false); b.icon:SetVertexColor(1, 1, 1)
      b.border:Hide(); b.num:SetText(""); b.check:Hide(); b.isNext = false
    end
    local sel = selected and selected.kind == "item" and selected.key == b.key and b.key
    if sel then b.sel:Show() else b.sel:Hide() end
  end
end

refreshMenu = function()
  if not db then return end
  local got, order = 0, setOrder()
  for _, i in ipairs(order) do if db.done[ITEMS[i].name] then got = got + 1 end end
  local rank = rankFor(#order > 0 and got / #order or 0)
  mProg:SetText(("%d / %d items  |cffffd200Rank: %s|r"):format(got, #order, rank))
  rankLine:SetText(("|cffffd200%s|r  -  %s  -  %d/%d"):format(rank, SET_NAMES[db.set] or "?", got, #order))
  who:SetText((UnitName and UnitName("player") or "Big Gourt"):upper())
  setMain:SetText(specLabel(db.spec) .. ": " .. (SET_NAMES[db.set] or "pick a set") .. "  v")
  for key, b in pairs(setBtns) do b:SetEnabled(db.set ~= key) end
  fillSlots()
  showDetails()
end

-- pulse the "up next" slot and rotate the quote
local quoteT, pulseT = 0, 0
M:SetScript("OnUpdate", function(_, e)
  quoteT = quoteT - e
  if quoteT <= 0 then quoteT = 9; mQuote:SetText("|cffffd200Gourt says:|r \"" .. pick(QUOTES) .. "\"") end
  pulseT = pulseT + e
  local a = 0.5 + 0.5 * math.sin(pulseT * 5)
  for _, b in ipairs(slots) do
    if b.isNext then b.border:SetAlpha(0.4 + 0.6 * a); b.border:SetVertexColor(1, 0.82, 0.1) else b.border:SetAlpha(1) end
  end
end)

selectFirstOpen = function()
  for _, i in ipairs(setOrder()) do
    if not db.done[ITEMS[i].name] then selected = { kind = "item", key = i } return end
  end
  selected = nil
end

for _, b in ipairs(slots) do
  b:SetScript("OnClick", function(self, btn)
    if not self.key then return end
    if btn == "RightButton" then
      startGuide("item", self.key)
    else
      selected = { kind = "item", key = self.key }
      refreshMenu()
    end
  end)
  b:SetScript("OnDoubleClick", function(self) if self.key then startGuide("item", self.key) end end)
  b:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    if not self.key then
      GameTooltip:AddLine(self.slotName .. ": nothing in this set", 0.6, 0.6, 0.6)
    else
      local it = ITEMS[self.key]
      local id = ITEM_IDS[it.name]
      if id then GameTooltip:SetHyperlink("item:" .. id) else GameTooltip:AddLine(it.name) end
      GameTooltip:AddLine(" ")
      GameTooltip:AddLine(("#%d  %s"):format(NUM[self.key] or 0, DIFF[it.diff]), 1, 1, 1)
      GameTooltip:AddLine(it.where, 0.75, 0.75, 0.75, true)
      GameTooltip:AddLine(db.done[it.name] and "You have it. Gourt approves." or "Left-click: details   Right-click: guide me", 0.4, 0.86, 0.4)
    end
    GameTooltip:Show()
  end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
end
for _, b in ipairs(placeBtns) do
  b:SetScript("OnClick", function(self) selected = { kind = "route", key = self.key }; refreshMenu() end)
end
dGo:SetScript("OnClick", function() if selected then startGuide(selected.kind, selected.key) end end)
dGot:SetScript("OnClick", function()
  if not (selected and selected.kind == "item") then return end
  local it = ITEMS[selected.key]
  db.done[it.name] = (not db.done[it.name]) or nil
  if db.done[it.name] then celebrate(it) end
  refreshMenu(); refreshArrow()
end)
------------------------------------------------------------------------
-- Swap items: replace any slot of a set with an item you prefer
------------------------------------------------------------------------
local dSwap = button(M, "Swap", 96, 26); dSwap:SetPoint("LEFT", dGot, "RIGHT", 8, 0)
local SW = newFrame("GourtsGearingSwap", M)
SW:SetSize(330, 330)
SW:SetPoint("CENTER", M, "CENTER", 0, 0)
SW:SetFrameStrata("DIALOG")
skin(SW, 0.98)
SW:EnableMouse(true)
SW:Hide()
tinsert(UISpecialFrames, "GourtsGearingSwap")
local swTitle = SW:CreateFontString(nil, "OVERLAY", "GameFontNormal")
swTitle:SetPoint("TOPLEFT", 12, -12); swTitle:SetPoint("RIGHT", -30, 0); swTitle:SetJustifyH("LEFT")
local swClose = CreateFrame("Button", nil, SW, "UIPanelCloseButton"); swClose:SetPoint("TOPRIGHT", 2, 2)
local swHelp = SW:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
swHelp:SetPoint("TOPLEFT", 12, -34); swHelp:SetPoint("RIGHT", -12, 0); swHelp:SetJustifyH("LEFT")
swHelp:SetText("Shift-click any item (bags, chat, Auction House, loot) into the box, or type an item ID, then press Enter.")
local swEdit = CreateFrame("EditBox", "GourtsGearingSwapEdit", SW, "InputBoxTemplate")
swEdit:SetSize(220, 22); swEdit:SetPoint("TOPLEFT", 18, -68); swEdit:SetAutoFocus(false)
local swUse = button(SW, "Use", 70, 22); swUse:SetPoint("LEFT", swEdit, "RIGHT", 8, 0)
local swMsg = SW:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
swMsg:SetPoint("TOPLEFT", 12, -94); swMsg:SetPoint("RIGHT", -12, 0); swMsg:SetJustifyH("LEFT"); swMsg:SetTextColor(1, 0.5, 0.5)
local swSub = SW:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
swSub:SetPoint("TOPLEFT", 12, -112); swSub:SetText("Suggestions")
local swPicks = {}
for i = 1, 7 do
  local b = button(SW, "", 306, 20)
  b:SetPoint("TOPLEFT", 12, -126 - (i - 1) * 22)
  swPicks[i] = b
end
local swReset = button(SW, "Use the guide's item again", 306, 22); swReset:SetPoint("BOTTOMLEFT", 12, 12)
if hooksecurefunc and ChatEdit_InsertLink then
  hooksecurefunc("ChatEdit_InsertLink", function(text) if SW:IsShown() and swEdit:HasFocus() and text then swEdit:Insert(text) end end)
end

local swPos -- position in the current set being swapped
local function itemName(id)
  local n = GetItemInfo and GetItemInfo(id)
  if not n and C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
  return n
end
local function doSwap(newId)
  db.custom = db.custom or {}
  db.custom[db.set] = db.custom[db.set] or {}
  db.custom[db.set][swPos] = newId
  applyCustom(db.set, db.custom)
  local idx = newId and ID_INDEX[newId]
  if not idx then for i, it in ipairs(ITEMS) do if SET_POS[db.set][i] == swPos then idx = i end end end
  selected = idx and { kind = "item", key = idx } or selected
  SW:Hide()
  refreshMenu()
end
local function openSwap()
  if not (selected and selected.kind == "item") then return end
  swPos = SET_POS[db.set] and SET_POS[db.set][selected.key]
  if not swPos then return end
  local it = ITEMS[selected.key]
  swTitle:SetText("Swap " .. it.slot .. ": " .. it.name)
  swMsg:SetText(""); swEdit:SetText("")
  -- suggestions: the set's listed alternatives, then items of this slot from your other sets
  local seen, list = { [selected.key] = true }, {}
  for i in pairs(SET_POS[db.set] or {}) do seen[i] = true end
  local sp = SPEC_BY_KEY[db.spec]
  for _, st in ipairs(sp and sp.sets or {}) do
    if st.key == db.set and st.alts and st.alts[it.slot] then
      for _, id in ipairs(st.alts[it.slot]) do local i = ID_INDEX[id]; if i and not seen[i] then seen[i] = true; list[#list + 1] = i end end
    end
  end
  for _, key in ipairs(SET_ORDER) do
    for i in pairs(SET_POS[key] or {}) do
      if ITEMS[i].slot == it.slot and not seen[i] then seen[i] = true; list[#list + 1] = i end
    end
  end
  for n, b in ipairs(swPicks) do
    local i = list[n]
    if i then
      local x = ITEMS[i]
      b:SetText((EPIC[x.name] and "|cffc07cff" or "|cff4aa3ff") .. x.name .. "|r  |cffaaaaaa" .. (x.where or ""):sub(1, 28) .. "|r")
      b.idx = i; b:Show()
    else b:Hide() end
  end
  swSub:SetShown(#list > 0)
  SW:Show(); swEdit:SetFocus()
end
local function useEdit()
  local t = swEdit:GetText() or ""
  local id = tonumber(t:match("item:(%d+)") or t:match("^%s*(%d+)%s*$"))
  if not id then swMsg:SetText("Shift-click an item into the box or type its item ID."); return end
  doSwap(id)
end
swUse:SetScript("OnClick", useEdit)
swEdit:SetScript("OnEnterPressed", useEdit)
swEdit:SetScript("OnEscapePressed", function() SW:Hide() end)
for _, b in ipairs(swPicks) do b:SetScript("OnClick", function(self) doSwap(ITEMS[self.idx].id) end) end
swReset:SetScript("OnClick", function() doSwap(nil) end)
dSwap:SetScript("OnClick", openSwap)
GourtsGearingSwapButton = dSwap

M:SetScript("OnShow", function()
  nextPic(); applyView()
  if model.SetUnit then model:SetUnit("player") end
  if model.SetFacing then model:SetFacing(model.facing) end
  if not selected then selectFirstOpen() end
  refreshMenu()
end)

------------------------------------------------------------------------
-- "By source" view: every item grouped by where it comes from
------------------------------------------------------------------------
local SRC_CATS = { { "all", "All" }, { "dungeon", "Dungeons" }, { "quest", "Quests / T0.5" },
  { "vendor", "Vendors" }, { "rep", "Rep / PvP" }, { "craft", "Crafted / AH" } }
local srcPanel = newFrame(nil, M)
srcPanel:SetAllPoints(doll)
if srcPanel.SetBackdrop then
  srcPanel:SetBackdrop(BACKDROP)
  srcPanel:SetBackdropColor(0.02, 0.02, 0.03, 0.95)
  srcPanel:SetBackdropBorderColor(0.45, 0.38, 0.25, 1)
end
srcPanel:Hide()
srcPanel:EnableMouseWheel(true)

local srcCat, srcMine, srcOffset = "all", false, 0
local catBtns = {}
for i, c in ipairs(SRC_CATS) do
  local b = button(srcPanel, c[2], 110, 20)
  b:SetPoint("TOPLEFT", 10 + ((i - 1) % 3) * 114, -10 - math.floor((i - 1) / 3) * 22)
  b.key = c[1]
  catBtns[i] = b
end
local mineBtn = button(srcPanel, "", 340, 20)
mineBtn:SetPoint("TOPLEFT", 10, -56)

local SROWS = 16
local srows = {}
for i = 1, SROWS do
  local r = CreateFrame("Button", nil, srcPanel)
  r:SetSize(340, 22)
  r:SetPoint("TOPLEFT", 10, -82 - (i - 1) * 22)
  r:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
  r.bg = r:CreateTexture(nil, "BACKGROUND"); r.bg:SetAllPoints(); r.bg:SetColorTexture(1, 0.82, 0.1, 0.25)
  r.icon = r:CreateTexture(nil, "ARTWORK"); r.icon:SetSize(18, 18); r.icon:SetPoint("LEFT", 4, 0)
  r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
  r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  r.text:SetPoint("LEFT", 26, 0); r.text:SetPoint("RIGHT", -4, 0); r.text:SetJustifyH("LEFT")
  r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  srows[i] = r
end

local srcLines = {}
local function buildSrc()
  wipe(srcLines)
  local set = db.set or ""
  local inSpec = {}
  for _, key in ipairs(SET_ORDER) do inSpec[key] = true end
  local groups, order = {}, {}
  for idx, it in ipairs(ITEMS) do
    local any = false
    for key in pairs(it.sets) do if inSpec[key] then any = true break end end
    local g = it.group
    if any and g and (not srcMine or it.sets[set]) then
      local c = g[1] == "other" and "craft" or (g[1] == "raid" and "craft" or g[1])
      if srcCat == "all" or c == srcCat then
        local k = c .. "|" .. g[2]
        if not groups[k] then groups[k] = { cat = c, name = g[2], where = g[3], items = {}, mine = 0 }; order[#order + 1] = k end
        local gr = groups[k]
        gr.items[#gr.items + 1] = { idx = idx, detail = g[4] }
        if it.sets[set] then gr.mine = gr.mine + 1 end
      end
    end
  end
  local catRank = { dungeon = 1, quest = 2, vendor = 3, rep = 4, craft = 5 }
  table.sort(order, function(a, b)
    local A, B = groups[a], groups[b]
    if A.cat ~= B.cat then return (catRank[A.cat] or 9) < (catRank[B.cat] or 9) end
    return #A.items > #B.items
  end)
  for _, k in ipairs(order) do
    local gr = groups[k]
    srcLines[#srcLines + 1] = { header = true, name = gr.name, where = (gr.where or ""):sub(1, 40), mine = gr.mine }
    for _, x in ipairs(gr.items) do srcLines[#srcLines + 1] = x end
  end
end

local function drawSources()
  if not db then return end
  buildSrc()
  local set = db.set or ""
  for _, b in ipairs(catBtns) do b:SetEnabled(b.key ~= srcCat) end
  mineBtn:SetText(srcMine and ("Only: " .. (SET_NAMES[set] or "?") .. "  (click for whole spec)") or ("Whole spec  (click for only " .. (SET_NAMES[set] or "?") .. ")"))
  srcOffset = math.max(0, math.min(srcOffset, #srcLines - SROWS))
  for i, r in ipairs(srows) do
    local ln = srcLines[i + srcOffset]
    r.line = ln
    r.bg:Hide()
    if not ln then
      r:Hide()
    elseif ln.header then
      r.icon:Hide()
      r.text:SetText(("|cffffd200%s|r  |cff888888%s|r%s"):format(ln.name, ln.where, ln.mine > 0 and ("  |cffc07cff" .. ln.mine .. " for your set|r") or ""))
      r:Show()
    else
      local it = ITEMS[ln.idx]
      local done = db.done[it.name]
      r.icon:Show()
      r.icon:SetTexture(itemIcon(ITEM_IDS[it.name] or 0))
      r.icon:SetDesaturated(not done)
      local col = EPIC[it.name] and "|cffc07cff" or "|cff4aa3ff"
      local mark = it.sets[set] and "|cffffd200*|r " or "   "
      r.text:SetText(("%s%s%s|r%s  |cffaaaaaa%s|r"):format(mark, col, it.name, done and " |cff3ddc3d(got)|r" or "", ln.detail))
      if selected and selected.kind == "item" and selected.key == ln.idx then r.bg:Show() end
      r:Show()
    end
  end
end

for _, b in ipairs(catBtns) do
  b:SetScript("OnClick", function(self) srcCat = self.key; srcOffset = 0; drawSources() end)
end
mineBtn:SetScript("OnClick", function() srcMine = not srcMine; srcOffset = 0; drawSources() end)
srcPanel:SetScript("OnMouseWheel", function(_, d) srcOffset = math.max(0, srcOffset - d * 3); drawSources() end)
for _, r in ipairs(srows) do
  r:SetScript("OnClick", function(self, btn)
    local ln = self.line
    if not ln or ln.header then return end
    if btn == "RightButton" then startGuide("item", ln.idx) return end
    selected = { kind = "item", key = ln.idx }
    refreshMenu()
  end)
  r:SetScript("OnDoubleClick", function(self) if self.line and not self.line.header then startGuide("item", self.line.idx) end end)
  r:SetScript("OnEnter", function(self)
    local ln = self.line
    if not ln or ln.header then return end
    local id = ITEM_IDS[ITEMS[ln.idx].name]
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    if id then GameTooltip:SetHyperlink("item:" .. id) end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("* = in your current set. Left-click: details  Right-click: guide me", 0.4, 0.86, 0.4, true)
    GameTooltip:Show()
  end)
  r:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-- switch between the gear sheet and the source list
local modeBtn = button(M, "By source", 100, 22)
modeBtn:SetPoint("RIGHT", setMain, "LEFT", -6, 0)
local function applyMode()
  if db.menuMode == "src" then
    doll:Hide(); srcPanel:Show(); modeBtn:SetText("Gear sheet"); drawSources()
  else
    srcPanel:Hide(); doll:Show(); modeBtn:SetText("By source")
  end
end
modeBtn:SetScript("OnClick", function() db.menuMode = (db.menuMode == "src") and "doll" or "src"; applyMode() end)
local baseRefresh = refreshMenu
refreshMenu = function()
  baseRefresh()
  if srcPanel:IsShown() then drawSources() end
end
M:HookScript("OnShow", applyMode)

------------------------------------------------------------------------
-- Tooltips + bag highlights for items in any Gourt's Gearing set
------------------------------------------------------------------------
local TIP_SETS = {}
local function loadTipSets()
  wipe(TIP_SETS)
  local cf
  if UnitClass then cf = select(2, UnitClass("player")) end
  local cls = cf and cf:lower() or "warrior"
  for _, sp in ipairs(SPECS) do
    if sp.cls == cls or (db and sp.key == db.spec) then
      for _, st in ipairs(sp.sets) do TIP_SETS[#TIP_SETS + 1] = st.key end
    end
  end
end
local ID_TO_ITEM = {}
for i, it in ipairs(ITEMS) do
  local id = ITEM_IDS[it.name]
  if id then ID_TO_ITEM[id] = i end
end
local GP_ICON = "|TInterface\\Icons\\INV_Shield_06:14:14:0:0:64:64:5:59:5:59|t"

local function setPositions(idx)
  -- { {setKey, position-in-that-set}, ... } without touching the menu's numbering
  local out = {}
  for _, key in ipairs(TIP_SETS) do
    if ITEMS[idx].sets[key] then
      local pos = 1
      local me = ITEMS[idx]
      local sp = SET_POS[key] or {}
      for j, it in ipairs(ITEMS) do
        if it.sets[key] and j ~= idx and (it.diff < me.diff or (it.diff == me.diff and (sp[j] or j) < (sp[idx] or idx))) then pos = pos + 1 end
      end
      out[#out + 1] = { key, pos }
    end
  end
  return out
end

local function itemIDFromLink(link)
  return link and tonumber(link:match("item:(%d+)"))
end

local function decorate(tt, id)
  if not (db and id) then return end
  local idx = ID_TO_ITEM[id]
  if not idx or tt.gpDone == id then return end
  if #setPositions(idx) == 0 then return end
  tt.gpDone = id
  local it = ITEMS[idx]
  -- mark the name line
  local name = tt.GetName and tt:GetName()
  local first = name and _G[name .. "TextLeft1"]
  local pos = setPositions(idx)
  if first and first.GetText and first:GetText() and not first:GetText():find("INV_Shield_06", 1, true) then
    -- tag right after the name: current set first (gold), then how many other sets
    local main, others = nil, 0
    for _, p in ipairs(pos) do
      if p[1] == db.set then main = p end
    end
    for _, p in ipairs(pos) do if p ~= main then others = others + 1 end end
    local tag
    if main then
      tag = ("|cffffd200[%s #%d]|r"):format(shortSet(main[1]), main[2])
    else
      local p = pos[1]
      tag = ("|cffc0b0d8[%s #%d]|r"):format(shortSet(p[1]), p[2])
      others = others - 1
    end
    if others > 0 then tag = tag .. (" |cffc0b0d8+%d|r"):format(others) end
    if db.done[it.name] then tag = tag .. " |TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t" end
    first:SetText(GP_ICON .. " " .. first:GetText() .. "  " .. tag)
  end
  -- set list
  tt:AddLine(" ")
  tt:AddLine(GP_ICON .. " Gourt's Gearing" .. (db.done[it.name] and "  |cff3ddc3d(you have it)|r" or ""), 0.75, 0.49, 1)
  for _, p in ipairs(pos) do
    local mine = (p[1] == db.set)
    tt:AddLine(("%s%s  #%d|r"):format(mine and "|cffffd200> " or "|cffc0b0d8  ", shortSet(p[1]), p[2] or 0))
  end
  tt:AddLine("  " .. it.where, 0.65, 0.65, 0.65, true)
  -- purple border
  if type(tt.NineSlice) == "table" and tt.NineSlice.SetBorderColor then
    tt.NineSlice:SetBorderColor(0.75, 0.3, 1)
  elseif tt.SetBackdropBorderColor then
    tt:SetBackdropBorderColor(0.75, 0.3, 1)
  end
  tt:Show()
end

local function onItemTooltip(tt)
  if not tt.GetItem then return end
  local _, link = tt:GetItem()
  decorate(tt, itemIDFromLink(link))
end

local hookedTips = {}
local function hookTooltip(tt)
  if not tt or hookedTips[tt] then return end
  hookedTips[tt] = true
  if tt.HookScript then
    tt:HookScript("OnTooltipCleared", function(self) self.gpDone = nil end)
    if not (TooltipDataProcessor and Enum and Enum.TooltipDataType) then
      tt:HookScript("OnTooltipSetItem", onItemTooltip)
    end
  end
end
if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
  TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, data)
    if data and data.id then decorate(tt, data.id) else onItemTooltip(tt) end
  end)
end
for _, n in ipairs({ "GameTooltip", "ItemRefTooltip", "ShoppingTooltip1", "ShoppingTooltip2" }) do hookTooltip(_G[n]) end

-- bag highlights (default Blizzard bags)
local function bagItemID(bag, slot)
  if C_Container and C_Container.GetContainerItemID then return C_Container.GetContainerItemID(bag, slot) end
  if GetContainerItemID then return GetContainerItemID(bag, slot) end
end
local function markButton(btn, idx)
  if not btn.gpMark then
    btn.gpMark = btn:CreateTexture(nil, "OVERLAY", nil, 7)
    btn.gpMark:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    btn.gpMark:SetBlendMode("ADD")
    btn.gpMark:SetPoint("CENTER")
    btn.gpMark:SetSize((btn:GetWidth() or 37) * 1.8, (btn:GetHeight() or 37) * 1.8)
    btn.gpStar = btn:CreateTexture(nil, "OVERLAY", nil, 7)
    btn.gpStar:SetTexture("Interface\\Icons\\INV_Shield_06")
    btn.gpStar:SetSize(14, 14)
    btn.gpStar:SetPoint("TOPLEFT", 1, -1)
  end
  if idx then
    local mine = ITEMS[idx].sets[db.set or "bis"]
    if mine then btn.gpMark:SetVertexColor(1, 0.82, 0.1) else btn.gpMark:SetVertexColor(0.75, 0.3, 1) end
    btn.gpMark:Show(); btn.gpStar:Show()
  else
    btn.gpMark:Hide(); btn.gpStar:Hide()
  end
end
local function updateBags()
  if not db or db.noBagGlow then return end
  for f = 1, 13 do
    local frame = _G["ContainerFrame" .. f]
    if frame and frame:IsShown() then
      local bag = frame.GetID and frame:GetID()
      for s = 1, 36 do
        local btn = _G["ContainerFrame" .. f .. "Item" .. s]
        if btn and btn:IsShown() and bag then
          local id = bagItemID(bag, btn:GetID())
          markButton(btn, id and ID_TO_ITEM[id])
        end
      end
    end
  end
end

-- auto-tick: anything from a list in your bags or worn counts as "got"
local firstScan = true
local function scanOwned()
  if not db or db.noAutoTick then return end
  local found = {}
  for bag = 0, 4 do
    local n = (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag)) or (GetContainerNumSlots and GetContainerNumSlots(bag)) or 0
    for slot = 1, n do
      local id = bagItemID(bag, slot)
      if id and ID_TO_ITEM[id] then found[ID_TO_ITEM[id]] = true end
    end
  end
  for inv = 1, 19 do
    local id = GetInventoryItemID and GetInventoryItemID("player", inv)
    if id and ID_TO_ITEM[id] then found[ID_TO_ITEM[id]] = true end
  end
  local new = false
  for idx in pairs(found) do
    local it = ITEMS[idx]
    if not db.done[it.name] then
      db.done[it.name] = true
      new = true
      if not firstScan then celebrate(it) end
    end
  end
  firstScan = false
  if new then refreshMenu(); refreshArrow() end
end

local tipEv = CreateFrame("Frame")
tipEv:RegisterEvent("BAG_UPDATE_DELAYED")
tipEv:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
tipEv:RegisterEvent("PLAYER_ENTERING_WORLD")
tipEv:SetScript("OnEvent", function(_, event)
  if event == "PLAYER_ENTERING_WORLD" and C_Timer and C_Timer.After then
    C_Timer.After(3, scanOwned)
  else
    scanOwned()
  end
  updateBags()
end)
if hooksecurefunc then
  if ContainerFrame_Update then hooksecurefunc("ContainerFrame_Update", updateBags) end
  if ContainerFrame_OnShow then hooksecurefunc("ContainerFrame_OnShow", updateBags) end
  if ToggleBackpack then hooksecurefunc("ToggleBackpack", function() if C_Timer then C_Timer.After(0.1, updateBags) end end) end
  if OpenAllBags then hooksecurefunc("OpenAllBags", function() if C_Timer then C_Timer.After(0.1, updateBags) end end) end
end

------------------------------------------------------------------------
-- Minimap button
------------------------------------------------------------------------
local MB = CreateFrame("Button", "GearPathMinimapButton", Minimap)
MB:SetSize(32, 32)
MB:SetFrameStrata("MEDIUM")
MB:SetFrameLevel(8)
MB:RegisterForClicks("LeftButtonUp", "RightButtonUp")
MB:RegisterForDrag("LeftButton")
MB:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
local icon = MB:CreateTexture(nil, "BACKGROUND")
icon:SetTexture("Interface\\Icons\\INV_Shield_06")
icon:SetSize(20, 20)
icon:SetPoint("CENTER", 0, 1)
icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
local ring = MB:CreateTexture(nil, "OVERLAY")
ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
ring:SetSize(54, 54)
ring:SetPoint("TOPLEFT")

local function placeMB()
  local a = math.rad(db.mmAngle or 200)
  MB:ClearAllPoints()
  MB:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * 80, math.sin(a) * 80)
end
MB:SetScript("OnDragStart", function(self)
  self:SetScript("OnUpdate", function()
    local mx, my = Minimap:GetCenter()
    local cx, cy = GetCursorPosition()
    local s = Minimap:GetEffectiveScale()
    db.mmAngle = math.deg(math.atan2(cy / s - my, cx / s - mx))
    placeMB()
  end)
end)
MB:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
MB:SetScript("OnClick", function(_, btn)
  if btn == "RightButton" then
    if A:IsShown() then A:Hide() else refreshArrow(); A:Show() end
  else
    if M:IsShown() then M:Hide() else M:Show() end
  end
end)
MB:SetScript("OnEnter", function(self)
  GameTooltip:SetOwner(self, "ANCHOR_LEFT")
  GameTooltip:AddLine("Gourt's Gearing", 0.75, 0.49, 1)
  local order, got = setOrder(), 0
  for _, i in ipairs(order) do if db.done[ITEMS[i].name] then got = got + 1 end end
  GameTooltip:AddLine("Rank: " .. rankFor(#order > 0 and got / #order or 0), 1, 0.82, 0.1)
  GameTooltip:AddLine(specLabel(db.spec) .. ": " .. (SET_NAMES[db.set] or "?"), 0.4, 0.86, 0.4)
  GameTooltip:AddLine("Left-click: open the menu", 1, 1, 1)
  GameTooltip:AddLine("Right-click: show/hide the arrow", 1, 1, 1)
  GameTooltip:AddLine("Drag: move this button", 0.6, 0.6, 0.6)
  GameTooltip:AddLine(" ")
  GameTooltip:AddLine("\"" .. pick(QUOTES) .. "\"", 0.85, 0.75, 1, true)
  GameTooltip:Show()
end)
MB:SetScript("OnLeave", function() GameTooltip:Hide() end)

------------------------------------------------------------------------
-- Load / slash
------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(_, event, name)
  if event == "ADDON_LOADED" and name == ADDON then
    GearPathDB = GearPathDB or {}
    db = GearPathDB
    db.done = db.done or {}
    -- upgrade from version 1 (which stored item/step numbers)
    if db.item and not db.guide then
      if ITEMS[db.item] then db.guide = { kind = "item", key = db.item } end
      db.item = nil
    end
    db.step = db.step or 1
    local OLDSET = { bis = "sim-best-set", budget = "sim-broke-boi", wh_bal = "balanced", wh_off = "offensive", wh_def = "defensive", wh_bud = "budget" }
    if db.set and OLDSET[db.set] then db.set = "warrior/protection:" .. OLDSET[db.set]; db.spec = "warrior/protection" end
    if (db.dataVersion or 0) < 3 then db.guide = nil; db.step = 1; db.dataVersion = 3 end
    if not db.spec or not SPEC_BY_KEY[db.spec] then
      local _, cf = UnitClass("player")
      db.spec = defaultSpecFor(cf and cf:lower() or "warrior")
    end
    db.custom = db.custom or {}
    for key in pairs(db.custom) do applyCustom(key, db.custom) end
    loadSpecSets(db.spec)
    if not (db.set and SET_SPEC[db.set] == db.spec) then db.set = SET_ORDER[1] end
    if db.shown == nil then db.shown = true end
    makeMovable(A, "pos")
    makeMovable(M, "menuPos")
    if db.pos then A:ClearAllPoints(); A:SetPoint(db.pos[1], UIParent, db.pos[2], db.pos[3], db.pos[4]) end
    if db.menuPos then M:ClearAllPoints(); M:SetPoint(db.menuPos[1], UIParent, db.menuPos[2], db.menuPos[3], db.menuPos[4]) end
  elseif event == "PLAYER_LOGIN" then
    faction = UnitFactionGroup("player")
    loadTipSets()
    print("|cffc07cffGourt's Gearing|r loaded. |cffaaaaaa" .. pick(QUOTES) .. "|r")
    placeMB()
    refreshArrow()
    if db.shown and db.guide then A:Show() end
    A:SetScript("OnShow", function() db.shown = true end)
    A:SetScript("OnHide", function() db.shown = false end)
  end
end)

SLASH_GEARPATH1 = "/gp"
SLASH_GEARPATH2 = "/gourtsgearing"
SLASH_GEARPATH3 = "/gourt"
SlashCmdList.GEARPATH = function(msg)
  msg = (msg or ""):lower()
  if msg == "reset" then
    db.done, db.guide, db.step = {}, nil, 1
    refreshArrow(); refreshMenu()
    print("|cffc07cffGourt's Gearing:|r reset.")
  elseif msg == "spec" then
    M:Show(); setMain:Click()
  elseif msg == "set" then
    local idx = 1
    for i, k in ipairs(SET_ORDER) do if k == db.set then idx = i end end
    db.set = SET_ORDER[idx % #SET_ORDER + 1]
    selected = nil; refreshMenu()
    print("|cffc07cffGourt's Gearing:|r showing the " .. SET_NAMES[db.set] .. ".")
  elseif msg == "gourt" or msg == "big gourt" then
    splash(msg == "gourt" and "GOURT" or "BIG GOURT", pick(QUOTES), pick(PICS))
  elseif msg == "raze" then
    splash("RAZE PULLED", pick({ "Everybody run.", "Again.", "Tank wasn't even in the group.", "Healer was drinking." }), PICS[3])
  elseif msg == "autotick" then
    db.noAutoTick = not db.noAutoTick
    print("|cffc07cffGourt's Gearing:|r auto-tick from bags/equipped is " .. (db.noAutoTick and "OFF" or "ON") .. ".")
  elseif msg == "glow" then
    db.noBagGlow = not db.noBagGlow
    print("|cffc07cffGourt's Gearing:|r bag highlights are " .. (db.noBagGlow and "OFF" or "ON") .. ".")
  elseif msg == "arrow" then
    if A:IsShown() then A:Hide() else refreshArrow(); A:Show() end
  else
    if M:IsShown() then M:Hide() else M:Show() end
  end
end

-- for troubleshooting with /dump GourtsGearingDebug
GourtsGearingDebug = { items = ITEMS, expand = expand }

-- shared with GourtsGearing_Extras.lua
NS.ITEMS, NS.ID_INDEX, NS.SET_POS, NS.SET_NAMES, NS.SET_SPEC = ITEMS, ID_INDEX, SET_POS, SET_NAMES, SET_SPEC
NS.SPEC_BY_KEY, NS.SPECS, NS.SET_ORDER, NS.CLASS_COLORS = SPEC_BY_KEY, SPECS, SET_ORDER, CLASS_COLORS
NS.getDB = function() return db end
NS.setOrder = function() return setOrder() end
NS.refresh = function() if refreshMenu then refreshMenu() end end
NS.splash, NS.PICS, NS.pick, NS.QUOTES, NS.rankFor = splash, PICS, pick, QUOTES, rankFor
NS.shortSet, NS.specLabel, NS.loadSpecSets, NS.applyCustom = shortSet, specLabel, loadSpecSets, applyCustom
NS.newFrame, NS.skin, NS.button, NS.makeMovable, NS.menu = newFrame, skin, button, makeMovable, M
NS.slash = SlashCmdList.GEARPATH
