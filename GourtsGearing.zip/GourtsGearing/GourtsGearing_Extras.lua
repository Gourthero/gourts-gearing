-- Gourt's Gearing extras: guild progress, loot-roll tags, dungeon planner, dungeon reminders,
-- gear check, Auction House highlights, crafting materials, ranks on player tooltips,
-- swap codes, sounds and wipe jokes.
-- Nothing here clicks, buys or moves for you: it only reads and shows.
local ADDON, NS = ...
if not NS or not NS.getDB then return end

local P = "|cffc07cffGourt's Gearing:|r "
local PREFIX = "GourtGear"
local ITEMS, ID_INDEX = NS.ITEMS, NS.ID_INDEX
local function DB() return NS.getDB() end
local function after(sec, fn) if C_Timer and C_Timer.After then C_Timer.After(sec, fn) else fn() end end
local function now() return (time and time()) or 0 end
local function short(name) return name and (name:gsub("%-.*$", "")) end
local ME = short(UnitName and UnitName("player")) or "?"
local CLASS_HEX = { WARRIOR = "c79c6e", PALADIN = "f58cba", HUNTER = "abd473", ROGUE = "fff569", PRIEST = "ffffff",
  SHAMAN = "0070de", MAGE = "69ccf0", WARLOCK = "9482c9", DRUID = "ff7d0a" }
local function cname(name, cls) return "|cff" .. (CLASS_HEX[cls or ""] or "c0b0d8") .. name .. "|r" end
local function itemName(id)
  local idx = ID_INDEX[id]
  if idx then return ITEMS[idx].name end
  return (GetItemInfo and GetItemInfo(id)) or ("item " .. id)
end
local function linkID(link) return link and tonumber(link:match("item:(%d+)")) end

------------------------------------------------------------------------
-- small UI helpers
------------------------------------------------------------------------
local function window(name, title, w, h)
  local f = NS.newFrame(name)
  f:SetSize(w, h)
  f:SetPoint("CENTER")
  f:SetFrameStrata("HIGH")
  NS.skin(f, 0.96)
  f:Hide()
  f:SetMovable(true); f:EnableMouse(true); f:SetClampedToScreen(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, name)
  local t = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  t:SetPoint("TOPLEFT", 14, -12); t:SetText(title)
  f.title = t
  local c = CreateFrame("Button", nil, f, "UIPanelCloseButton"); c:SetPoint("TOPRIGHT", 2, 2)
  return f
end
-- scrolling block of text
local function scrollText(parent, x, y, w, h)
  local sf = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
  sf:SetPoint("TOPLEFT", x, y); sf:SetSize(w, h)
  local child = CreateFrame("Frame", nil, sf); child:SetSize(w, h)
  sf:SetScrollChild(child)
  local fs = child:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  fs:SetPoint("TOPLEFT"); fs:SetWidth(w - 6); fs:SetJustifyH("LEFT"); fs:SetJustifyV("TOP")
  if fs.SetSpacing then fs:SetSpacing(2) end
  return function(text)
    fs:SetText(text)
    child:SetHeight(math.max(h, (fs:GetStringHeight() or h) + 10))
    sf:SetVerticalScroll(0)
  end
end

------------------------------------------------------------------------
-- Your progress, and other players' progress (guild + group sync)
------------------------------------------------------------------------
local function myStatus()
  local d = DB()
  local order, got, need = NS.setOrder(), 0, {}
  for _, i in ipairs(order) do
    local it = ITEMS[i]
    if d.done[it.name] then got = got + 1 else need[#need + 1] = it.id end
  end
  local cls = UnitClass and select(2, UnitClass("player"))
  return cls or "?", d.set or "?", got, #order, need
end
local function statusMsg()
  local cls, set, got, tot, need = myStatus()
  local msg = ("S|%s|%s|%d|%d|"):format(cls, set, got, tot)
  for i, id in ipairs(need) do
    local add = (i > 1 and "," or "") .. id
    if #msg + #add > 250 then break end
    msg = msg .. add
  end
  return msg
end
local function rankOf(got, tot) return NS.rankFor(tot > 0 and got / tot or 0) end

local function regPrefix()
  if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
  elseif RegisterAddonMessagePrefix then RegisterAddonMessagePrefix(PREFIX) end
end
local function send(msg, chan, target)
  if C_ChatInfo and C_ChatInfo.SendAddonMessage then C_ChatInfo.SendAddonMessage(PREFIX, msg, chan, target)
  elseif SendAddonMessage then SendAddonMessage(PREFIX, msg, chan, target) end
end
local function groupChan()
  if IsInRaid and IsInRaid() then return "RAID" end
  if IsInGroup and IsInGroup() then return "PARTY" end
end
local lastSent, lastMsg = {}, {}
local function broadcast(force)
  local d = DB(); if not d or d.noSync then return end
  local msg = statusMsg()
  for _, chan in ipairs({ (IsInGuild and IsInGuild()) and "GUILD" or false, groupChan() or false }) do
    if chan and (force or lastMsg[chan] ~= msg) and (GetTime() - (lastSent[chan] or -99) > 10) then
      lastSent[chan], lastMsg[chan] = GetTime(), msg
      send(msg, chan)
    end
  end
end

local function peers()
  local d = DB()
  d.peers = d.peers or {}
  return d.peers
end
local function inMyGroup(name)
  if not (IsInGroup and IsInGroup()) then return false end
  local n = GetNumGroupMembers and GetNumGroupMembers() or 0
  local raid = IsInRaid and IsInRaid()
  for i = 1, n do
    local u = raid and ("raid" .. i) or ("party" .. i)
    if UnitExists(u) and short(UnitName(u)) == name then return true end
  end
  return false
end

-- who still needs item id: "You" first, then synced players (optionally only your group)
local function needers(id, groupOnly)
  local d, out = DB(), {}
  if not d then return out end
  local idx = ID_INDEX[id]
  if idx and ITEMS[idx].sets[d.set or ""] and not d.done[ITEMS[idx].name] then out[#out + 1] = "|cffffd200You|r" end
  for name, p in pairs(peers()) do
    if name ~= ME and (not groupOnly or inMyGroup(name)) then
      for _, x in ipairs(p.need or {}) do
        if x == id then out[#out + 1] = cname(name, p.cls); break end
      end
    end
  end
  return out
end

local onPeerUpdate -- set by the guild window
local function onAddonMsg(prefix, msg, chan, sender)
  if prefix ~= PREFIX then return end
  local name = short(sender)
  if not name or name == ME then return end
  if msg == "R" then
    after(math.random() * 3, function()
      if chan == "GUILD" or chan == "PARTY" or chan == "RAID" then lastSent[chan] = nil; lastMsg[chan] = nil; broadcast(true) end
    end)
    return
  end
  local cls, set, got, tot, need = msg:match("^S|([^|]*)|([^|]*)|(%d+)|(%d+)|(.*)$")
  if not cls then return end
  local list = {}
  for id in need:gmatch("%d+") do list[#list + 1] = tonumber(id) end
  local pl = peers()
  pl[name] = { cls = cls, set = set, got = tonumber(got), tot = tonumber(tot), need = list, t = now(), guild = (chan == "GUILD") or (pl[name] and pl[name].guild) }
  if onPeerUpdate then onPeerUpdate() end
end

------------------------------------------------------------------------
-- 1. Guild progress window
------------------------------------------------------------------------
local GW = window("GourtsGearingGuild", "Guild progress", 520, 420)
local gwInfo = GW:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
gwInfo:SetPoint("TOPLEFT", 14, -36); gwInfo:SetPoint("RIGHT", -14, 0); gwInfo:SetJustifyH("LEFT")
gwInfo:SetText("Guildmates and group members with Gourt's Gearing share what they still need. Items in purple are still missing.")
local gwText = scrollText(GW, 14, -70, 470, 300)
local gwAsk = NS.button(GW, "Ask everyone again", 160, 22); gwAsk:SetPoint("BOTTOMLEFT", 12, 12)
local gwSync = NS.button(GW, "", 180, 22); gwSync:SetPoint("LEFT", gwAsk, "RIGHT", 8, 0)
local function ago(t)
  local s = now() - (t or 0)
  if s < 3600 then return math.max(1, math.floor(s / 60)) .. "m ago" end
  if s < 86400 then return math.floor(s / 3600) .. "h ago" end
  return math.floor(s / 86400) .. "d ago"
end
local function drawGuild()
  if not GW:IsShown() then return end
  local d = DB()
  gwSync:SetText(d.noSync and "Sharing: OFF" or "Sharing: ON")
  local rows = {}
  local cls, set, got, tot, need = myStatus()
  rows[1] = { name = ME, cls = cls, set = set, got = got, tot = tot, need = need, t = now(), me = true }
  for name, p in pairs(peers()) do rows[#rows + 1] = { name = name, cls = p.cls, set = p.set, got = p.got or 0, tot = p.tot or 0, need = p.need or {}, t = p.t } end
  table.sort(rows, function(a, b)
    if a.me ~= b.me then return a.me and true or false end
    return (a.tot > 0 and a.got / a.tot or 0) > (b.tot > 0 and b.got / b.tot or 0)
  end)
  local out = {}
  for _, r in ipairs(rows) do
    local setName = NS.SET_NAMES[r.set] and NS.shortSet(r.set) or (r.set or "?")
    out[#out + 1] = ("%s  |cffaaaaaa%s|r  |cffffd200%d/%d|r  %s%s"):format(cname(r.name, r.cls), setName, r.got, r.tot,
      rankOf(r.got, r.tot), r.me and "" or ("  |cff777777" .. ago(r.t) .. "|r"))
    local miss = {}
    for i, id in ipairs(r.need) do
      if i > 8 then miss[#miss + 1] = "+" .. (#r.need - 8) .. " more"; break end
      miss[#miss + 1] = itemName(id)
    end
    out[#out + 1] = "    |cffc07cff" .. (#miss > 0 and table.concat(miss, ", ") or "nothing! BIG GOURT") .. "|r"
    out[#out + 1] = " "
  end
  if #rows == 1 then out[#out + 1] = "|cffaaaaaaNobody else has shared yet. They need version 4.6 or newer, and to be in your guild or group.|r" end
  gwText(table.concat(out, "\n"))
end
GW:SetScript("OnShow", drawGuild)
gwAsk:SetScript("OnClick", function()
  if IsInGuild and IsInGuild() then send("R", "GUILD") end
  local g = groupChan(); if g then send("R", g) end
  broadcast(true)
  print(P .. "asked your guild and group for their progress.")
end)
gwSync:SetScript("OnClick", function()
  local d = DB(); d.noSync = not d.noSync
  print(P .. "sharing your progress is " .. (d.noSync and "OFF" or "ON") .. ".")
  drawGuild()
end)

------------------------------------------------------------------------
-- 2. Loot rolls and the loot window: who needs this?
------------------------------------------------------------------------
local function tagRollFrame(rollID, text)
  for i = 1, 4 do
    local f = _G["GroupLootFrame" .. i]
    if f and f.rollID == rollID then
      if not f.ggTag then
        f.ggTag = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        f.ggTag:SetPoint("BOTTOM", f, "TOP", 0, 2)
      end
      f.ggTag:SetText(text); f.ggTag:Show()
    elseif f and f.ggTag and f.rollID ~= rollID and not f:IsShown() then
      f.ggTag:Hide()
    end
  end
end
local function onRoll(rollID)
  local link = GetLootRollItemLink and GetLootRollItemLink(rollID)
  local id = linkID(link)
  if not id then return end
  local who = needers(id, true)
  if #who == 0 then return end
  local txt = "Gourt's Gearing: needed by " .. table.concat(who, ", ")
  print(P .. link .. " is on the list for " .. table.concat(who, ", ") .. ".")
  after(0.1, function() tagRollFrame(rollID, txt) end)
end
local lootSeen = {}
local function onLootOpened()
  if not (IsInGroup and IsInGroup()) then return end
  local n = GetNumLootItems and GetNumLootItems() or 0
  for s = 1, n do
    local link = GetLootSlotLink and GetLootSlotLink(s)
    local id = linkID(link)
    if id and not lootSeen[id] then
      local who = needers(id, true)
      if #who > 0 then
        lootSeen[id] = true
        after(120, function() lootSeen[id] = nil end)
        print(P .. link .. " dropped. Needed by " .. table.concat(who, ", ") .. ".")
      end
    end
  end
end

------------------------------------------------------------------------
-- 3. Dungeon planner + 6. reminders when you zone in
------------------------------------------------------------------------
local function norm(s) return ((s or ""):lower():gsub("%s*%b()", ""):gsub("^%s+", ""):gsub("%s+$", "")) end
local DUNGEONS, DORDER = {}, {}
for idx, it in ipairs(ITEMS) do
  local g = it.group
  if g and g[1] == "dungeon" and not it.custom then
    if not DUNGEONS[g[2]] then DUNGEONS[g[2]] = { name = g[2], where = g[3], items = {} }; DORDER[#DORDER + 1] = g[2] end
    local dd = DUNGEONS[g[2]]
    dd.items[#dd.items + 1] = { idx = idx, boss = (g[4] or ""):gsub("%s*%-%s*~.*$", "") }
  end
end
table.sort(DORDER)

-- every still-needed item of a dungeon: { {idx, boss, who = {...}} }
local function dungeonNeeds(dname, groupOnly)
  local out = {}
  for _, x in ipairs(DUNGEONS[dname].items) do
    local who = needers(ITEMS[x.idx].id, groupOnly)
    if #who > 0 then out[#out + 1] = { idx = x.idx, boss = x.boss, who = who } end
  end
  table.sort(out, function(a, b) if a.boss ~= b.boss then return a.boss < b.boss end return ITEMS[a.idx].name < ITEMS[b.idx].name end)
  return out
end
local function needsText(list)
  local out, lastBoss = {}, nil
  for _, x in ipairs(list) do
    if x.boss ~= lastBoss then
      out[#out + 1] = "|cffffd200" .. (x.boss ~= "" and x.boss:gsub("^%l", string.upper) or "Anywhere") .. "|r"
      lastBoss = x.boss
    end
    out[#out + 1] = "   |cff4aa3ff" .. ITEMS[x.idx].name .. "|r  " .. table.concat(x.who, ", ")
  end
  return table.concat(out, "\n")
end

local PW = window("GourtsGearingPlanner", "Dungeon planner", 640, 440)
local pwMode = false -- false = whole guild, true = my group only
local pwSel
local pwInfo = PW:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
pwInfo:SetPoint("TOPLEFT", 14, -36); pwInfo:SetPoint("RIGHT", -14, 0); pwInfo:SetJustifyH("LEFT")
pwInfo:SetText("Which dungeon is worth running? The number is how many items still needed by you and the people shown.")
local pwModeBtn = NS.button(PW, "", 200, 22); pwModeBtn:SetPoint("BOTTOMLEFT", 12, 12)
local pwHead = PW:CreateFontString(nil, "OVERLAY", "GameFontNormal")
pwHead:SetPoint("TOPLEFT", 236, -62); pwHead:SetPoint("RIGHT", -14, 0); pwHead:SetJustifyH("LEFT")
local pwText = scrollText(PW, 236, -100, 370, 290)
local pwSub = PW:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
pwSub:SetPoint("TOPLEFT", pwHead, "BOTTOMLEFT", 0, -4); pwSub:SetPoint("RIGHT", -14, 0); pwSub:SetJustifyH("LEFT")
local pwList = CreateFrame("ScrollFrame", nil, PW, "UIPanelScrollFrameTemplate")
pwList:SetPoint("TOPLEFT", 12, -62); pwList:SetSize(196, 330)
local pwChild = CreateFrame("Frame", nil, pwList); pwChild:SetSize(196, 330); pwList:SetScrollChild(pwChild)
local pwBtns = {}
local drawPlanner
local function pwShow(dname)
  pwSel = dname
  local dd = DUNGEONS[dname]
  pwHead:SetText(dname)
  pwSub:SetText(dd.where or "")
  local list = dungeonNeeds(dname, pwMode)
  pwText(#list > 0 and needsText(list) or "|cffaaaaaaNothing needed from here. Run it with Raze for fun.|r")
end
drawPlanner = function()
  if not PW:IsShown() then return end
  pwModeBtn:SetText(pwMode and "Showing: my group" or "Showing: whole guild")
  local rows = {}
  for _, dn in ipairs(DORDER) do rows[#rows + 1] = { name = dn, n = #dungeonNeeds(dn, pwMode) } end
  table.sort(rows, function(a, b) if a.n ~= b.n then return a.n > b.n end return a.name < b.name end)
  for i, r in ipairs(rows) do
    local b = pwBtns[i]
    if not b then
      b = CreateFrame("Button", nil, pwChild)
      b:SetSize(190, 20); b:SetPoint("TOPLEFT", 0, -(i - 1) * 21)
      b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
      b.fs = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.fs:SetPoint("LEFT", 4, 0); b.fs:SetWidth(184); b.fs:SetJustifyH("LEFT")
      b:SetScript("OnClick", function(self) pwShow(self.dname) end)
      pwBtns[i] = b
    end
    b.dname = r.name
    b.fs:SetText((r.n > 0 and "|cffffd200" .. r.n .. "|r  " or "|cff6666660|r  ") .. r.name)
    b:Show()
  end
  for i = #rows + 1, #pwBtns do pwBtns[i]:Hide() end
  pwChild:SetHeight(math.max(330, #rows * 21))
  if rows[1] then pwShow((pwSel and DUNGEONS[pwSel]) and pwSel or rows[1].name) end
end
PW:SetScript("OnShow", function() drawPlanner() end)
pwModeBtn:SetScript("OnClick", function() pwMode = not pwMode; drawPlanner() end)

-- reminder when you zone into a dungeon
local RW = window("GourtsGearingReminder", "Look out for", 360, 220)
RW:ClearAllPoints(); RW:SetPoint("TOP", UIParent, "TOP", 0, -140)
local rwText = scrollText(RW, 14, -40, 320, 160)
local rwHideAt = 0
RW:SetScript("OnUpdate", function(self) if GetTime() > rwHideAt and not self:IsMouseOver() then self:Hide() end end)
local lastInst
local function checkInstance()
  local d = DB(); if not d or d.noReminder then return end
  local inInst, typ = IsInInstance()
  if not inInst or (typ ~= "party" and typ ~= "raid") then lastInst = nil; return end
  local iname = GetInstanceInfo and GetInstanceInfo()
  if not iname or iname == lastInst then return end
  lastInst = iname
  local n = norm(iname)
  local lists, names = {}, {}
  for _, dn in ipairs(DORDER) do
    local m = norm(dn)
    if m ~= "" and (m:find(n, 1, true) or n:find(m, 1, true)) then
      for _, x in ipairs(dungeonNeeds(dn, true)) do lists[#lists + 1] = x end
      names[#names + 1] = dn
    end
  end
  if #lists == 0 then return end
  RW.title:SetText("Loot to look out for in " .. iname)
  rwText(needsText(lists))
  rwHideAt = GetTime() + 25
  RW:Show()
  print(P .. #lists .. " item(s) you or your group still need drop in " .. iname .. ". " .. NS.pick(NS.QUOTES))
end

------------------------------------------------------------------------
-- 4. Gear check (character sheet arrows + window)
------------------------------------------------------------------------
local SLOT_INV = { Head = { 1 }, Neck = { 2 }, Shoulder = { 3 }, Back = { 15 }, Chest = { 5 }, Wrist = { 9 }, Hands = { 10 },
  Waist = { 6 }, Legs = { 7 }, Feet = { 8 }, Ring = { 11, 12 }, Trinket = { 13, 14 }, ["Main hand"] = { 16 },
  ["Off hand"] = { 17 }, Ranged = { 18 } }
local INV_FRAME = { [1] = "Head", [2] = "Neck", [3] = "Shoulder", [15] = "Back", [5] = "Chest", [9] = "Wrist", [10] = "Hands",
  [6] = "Waist", [7] = "Legs", [8] = "Feet", [11] = "Finger0", [12] = "Finger1", [13] = "Trinket0", [14] = "Trinket1",
  [16] = "MainHand", [17] = "SecondaryHand", [18] = "Ranged" }
local function bagCount(id) return (GetItemCount and GetItemCount(id)) or 0 end
-- per inventory slot: "set" (wearing a set item), "up" (your set has something better), nil (no set item for it)
local function gearState()
  local d = DB()
  local worn = {}
  for inv = 1, 19 do local id = GetInventoryItemID and GetInventoryItemID("player", inv); if id then worn[id] = inv end end
  local bySlot = {}
  for _, i in ipairs(NS.setOrder()) do
    local it = ITEMS[i]
    if SLOT_INV[it.slot] then bySlot[it.slot] = bySlot[it.slot] or {}; table.insert(bySlot[it.slot], i) end
  end
  local state, rows, have, total = {}, {}, 0, 0
  for slot, list in pairs(bySlot) do
    local invs, freeInv = SLOT_INV[slot], {}
    for _, inv in ipairs(invs) do freeInv[inv] = true end
    local missing = {}
    for _, i in ipairs(list) do
      total = total + 1
      local inv = worn[ITEMS[i].id]
      if inv and freeInv[inv] ~= nil then
        freeInv[inv] = false; state[inv] = "set"; have = have + 1
        rows[#rows + 1] = { slot = slot, ok = true, idx = i }
      else
        missing[#missing + 1] = i
      end
    end
    for _, i in ipairs(missing) do
      local target
      for _, inv in ipairs(invs) do if freeInv[inv] then target = inv; freeInv[inv] = false; break end end
      if target then state[target] = "up" end
      rows[#rows + 1] = { slot = slot, ok = false, idx = i, inBags = bagCount(ITEMS[i].id) > 0, got = d.done[ITEMS[i].name] }
    end
  end
  return state, rows, have, total
end

local pdText
local function markPaperDoll()
  if not (PaperDollFrame and PaperDollFrame:IsShown()) then return end
  local d = DB(); if not d then return end
  local state, _, have, total = gearState()
  for inv, fname in pairs(INV_FRAME) do
    local b = _G["Character" .. fname .. "Slot"]
    if b then
      if not b.ggMark then
        b.ggMark = b:CreateTexture(nil, "OVERLAY", nil, 7)
        b.ggMark:SetSize(16, 16); b.ggMark:SetPoint("TOPRIGHT", 3, 3)
      end
      local s = (not d.noGearCheck) and state[inv]
      if s == "up" then b.ggMark:SetTexture("Interface\\Buttons\\UI-MicroStream-Green"); b.ggMark:Show()
      elseif s == "set" then b.ggMark:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready"); b.ggMark:Show()
      else b.ggMark:Hide() end
    end
  end
  if not pdText then
    pdText = PaperDollFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    pdText:SetPoint("TOP", PaperDollFrame, "TOP", 0, -56)
  end
  if d.noGearCheck or total == 0 then pdText:Hide() else
    pdText:SetText(("|cffc07cff%d%% Big Gourt|r  |cffaaaaaa(%d/%d set items worn, green = upgrade in your set)|r"):format(math.floor(have / total * 100 + 0.5), have, total))
    pdText:Show()
  end
end

local CW = window("GourtsGearingCheck", "Gear check", 460, 420)
local cwText = scrollText(CW, 14, -40, 410, 330)
local cwToggle = NS.button(CW, "", 220, 22); cwToggle:SetPoint("BOTTOMLEFT", 12, 12)
local SLOT_SORT = { Head = 1, Neck = 2, Shoulder = 3, Back = 4, Chest = 5, Wrist = 6, Hands = 7, Waist = 8, Legs = 9, Feet = 10, Ring = 11, Trinket = 12, ["Main hand"] = 13, ["Off hand"] = 14, Ranged = 15 }
local function drawCheck()
  if not CW:IsShown() then return end
  local d = DB()
  cwToggle:SetText(d.noGearCheck and "Character sheet arrows: OFF" or "Character sheet arrows: ON")
  local _, rows, have, total = gearState()
  table.sort(rows, function(a, b) if a.slot ~= b.slot then return (SLOT_SORT[a.slot] or 99) < (SLOT_SORT[b.slot] or 99) end return a.ok and not b.ok end)
  local out = { ("|cffc07cff%d%% Big Gourt|r: wearing %d of %d items from %s.\n"):format(total > 0 and math.floor(have / total * 100 + 0.5) or 0, have, total, NS.SET_NAMES[d.set] or "your set") }
  for _, r in ipairs(rows) do
    local it = ITEMS[r.idx]
    local st
    if r.ok then st = "|TInterface\\RaidFrame\\ReadyCheck-Ready:12:12|t |cff3ddc3dwearing it|r"
    elseif r.inBags then st = "|cffffd200in your bags: put it on!|r"
    elseif r.got then st = "|cffaaaaaaticked as got, not worn|r"
    else st = "|cffff8c33upgrade to get|r |cff777777(" .. (it.where or ""):sub(1, 40) .. ")|r" end
    out[#out + 1] = ("|cffaaaaaa%s:|r %s  %s"):format(r.slot, it.name, st)
  end
  cwText(table.concat(out, "\n"))
end
CW:SetScript("OnShow", drawCheck)
cwToggle:SetScript("OnClick", function() local d = DB(); d.noGearCheck = not d.noGearCheck; drawCheck(); markPaperDoll() end)
if PaperDollFrame and PaperDollFrame.HookScript then PaperDollFrame:HookScript("OnShow", function() after(0, markPaperDoll) end) end

------------------------------------------------------------------------
-- 5. Auction House: highlight set items for sale (reading only, never bids or buys)
------------------------------------------------------------------------
local ahSaid = {}
local function ahNote(id, link)
  local who = needers(id)
  if #who == 0 then return nil end
  if not ahSaid[id] or GetTime() - ahSaid[id] > 300 then
    ahSaid[id] = GetTime()
    print(P .. "on the Auction House: " .. (link or itemName(id)) .. " (needed by " .. table.concat(who, ", ") .. ")")
  end
  return who
end
local function scanBrowse()
  local d = DB(); if not d or d.noAH then return end
  if not (BrowseScrollFrame and GetAuctionItemLink) then return end
  local offset = FauxScrollFrame_GetOffset and FauxScrollFrame_GetOffset(BrowseScrollFrame) or 0
  for i = 1, (NUM_BROWSE_TO_DISPLAY or 8) do
    local b = _G["BrowseButton" .. i]
    if b then
      local link = GetAuctionItemLink("list", offset + i)
      local id = linkID(link)
      local who = id and b:IsShown() and ahNote(id, link)
      if not b.ggGlow then
        b.ggGlow = b:CreateTexture(nil, "OVERLAY")
        b.ggGlow:SetAllPoints(); b.ggGlow:SetColorTexture(1, 0.82, 0.1, 0.18)
        b.ggStar = b:CreateTexture(nil, "OVERLAY")
        b.ggStar:SetTexture("Interface\\Icons\\INV_Shield_06"); b.ggStar:SetSize(16, 16); b.ggStar:SetPoint("RIGHT", -4, 0)
      end
      b.ggGlow:SetShown(who and true or false); b.ggStar:SetShown(who and true or false)
    end
  end
end
local function scanModernAH()
  local d = DB(); if not d or d.noAH then return end
  if not (C_AuctionHouse and C_AuctionHouse.GetBrowseResults) then return end
  for _, r in ipairs(C_AuctionHouse.GetBrowseResults() or {}) do
    local id = r.itemKey and r.itemKey.itemID
    if id then ahNote(id) end
  end
end
local ahHooked = false
local function hookAH()
  if ahHooked then return end
  if AuctionFrameBrowse_Update and hooksecurefunc then hooksecurefunc("AuctionFrameBrowse_Update", scanBrowse); ahHooked = true end
end

------------------------------------------------------------------------
-- 7. Crafting materials (bags + bank)
------------------------------------------------------------------------
local function scanContainers(bags)
  local counts = {}
  for _, bag in ipairs(bags) do
    local n = (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag)) or (GetContainerNumSlots and GetContainerNumSlots(bag)) or 0
    for slot = 1, n do
      local link, cnt
      if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        if info then link, cnt = info.hyperlink, info.stackCount end
      elseif GetContainerItemInfo then
        local _, c, _, _, _, _, l = GetContainerItemInfo(bag, slot)
        link, cnt = l, c
      end
      local name = link and link:match("%[(.-)%]")
      if name then counts[name] = (counts[name] or 0) + (cnt or 1) end
    end
  end
  return counts
end
local function bankBags()
  local t = { BANK_CONTAINER or -1 }
  local first = (NUM_BAG_SLOTS or 4) + 1
  for b = first, first + (NUM_BANKBAGSLOTS or 6) - 1 do t[#t + 1] = b end
  return t
end
local MW = window("GourtsGearingMats", "Crafting materials", 460, 420)
local mwText = scrollText(MW, 14, -40, 410, 340)
local function drawMats()
  if not MW:IsShown() then return end
  local d = DB()
  local bags = scanContainers({ 0, 1, 2, 3, 4 })
  local bank = d.bank or {}
  local out = { "|cffaaaaaaBags + bank (the bank count updates each time you open your bank).|r\n" }
  local any = false
  for _, i in ipairs(NS.setOrder()) do
    local it = ITEMS[i]
    if it.mats and not d.done[it.name] then
      any = true
      local prof = it.group and it.group[2] or "Crafted"
      out[#out + 1] = ("|cff4aa3ff%s|r  |cffaaaaaa(%s%s)|r"):format(it.name, prof, it.boe and "" or ", you must craft it yourself")
      for _, m in ipairs(it.mats) do
        local need, name = m[1], m[2]
        local have = (bags[name] or 0) + (bank[name] or 0)
        local col = have >= need and "3ddc3d" or (have > 0 and "ffd200" or "ff6060")
        out[#out + 1] = ("    |cff%s%d/%d|r  %s"):format(col, math.min(have, need), need, name)
      end
      out[#out + 1] = " "
    end
  end
  if not any then out[#out + 1] = "No crafted items left in " .. (NS.SET_NAMES[d.set] or "your set") .. ". Either you have them all or this set has none." end
  mwText(table.concat(out, "\n"))
end
MW:SetScript("OnShow", drawMats)

------------------------------------------------------------------------
-- 8. Swap codes (same format on the web page)
--    GG1;<set key>;<position>=<item id>,...   positions start at 1
------------------------------------------------------------------------
local XW = window("GourtsGearingCode", "Share your swaps", 460, 170)
local xwHelp = XW:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
xwHelp:SetPoint("TOPLEFT", 14, -38); xwHelp:SetPoint("RIGHT", -14, 0); xwHelp:SetJustifyH("LEFT")
local xwEdit = CreateFrame("EditBox", "GourtsGearingCodeEdit", XW, "InputBoxTemplate")
xwEdit:SetSize(420, 22); xwEdit:SetPoint("TOPLEFT", 20, -80); xwEdit:SetAutoFocus(false)
local xwMsg = XW:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
xwMsg:SetPoint("TOPLEFT", 14, -108); xwMsg:SetPoint("RIGHT", -14, 0); xwMsg:SetJustifyH("LEFT")
local xwGo = NS.button(XW, "Import", 100, 22); xwGo:SetPoint("BOTTOMRIGHT", -12, 12)
local function exportCode()
  local d = DB()
  local set = d.set or ""
  local parts = {}
  local ov = d.custom and d.custom[set] or {}
  local keys = {}
  for pos in pairs(ov) do keys[#keys + 1] = pos end
  table.sort(keys)
  for _, pos in ipairs(keys) do parts[#parts + 1] = pos .. "=" .. ov[pos] end
  return "GG1;" .. set .. ";" .. table.concat(parts, ","), #parts
end
local function importCode(code)
  code = (code or ""):gsub("^%s+", ""):gsub("%s+$", "")
  local set, body = code:match("^GG1;([^;]+);(.*)$")
  if not set then return false, "That isn't a Gourt's Gearing swap code (they start with GG1;)." end
  if not NS.SET_NAMES[set] then return false, "This code is for a set this version doesn't know: " .. set end
  local d = DB()
  d.custom = d.custom or {}
  local ov = {}
  for pos, id in body:gmatch("(%d+)=(%d+)") do ov[tonumber(pos)] = tonumber(id) end
  d.custom[set] = ov
  NS.applyCustom(set, d.custom)
  d.spec = NS.SET_SPEC[set]
  NS.loadSpecSets(d.spec)
  d.set = set
  NS.refresh()
  return true, ("Loaded %s with %d swap(s)."):format(NS.shortSet(set), (function() local n = 0 for _ in pairs(ov) do n = n + 1 end return n end)())
end
local function openExport()
  local code, n = exportCode()
  XW.title:SetText("Share your swaps")
  xwHelp:SetText(n > 0 and "Copy this code (Ctrl+C) and paste it into the web page's \"Swap code\" box, or give it to a friend." or "You haven't swapped anything in this set yet. The code still picks the same set for whoever loads it.")
  xwEdit:SetText(code); xwMsg:SetText(""); xwGo:Hide()
  XW:Show(); xwEdit:SetFocus(); xwEdit:HighlightText()
end
local function openImport()
  XW.title:SetText("Load a swap code")
  xwHelp:SetText("Paste a code from the web page or a friend (Ctrl+V), then press Enter.")
  xwEdit:SetText(""); xwMsg:SetText(""); xwGo:Show()
  XW:Show(); xwEdit:SetFocus()
end
local function doImport()
  local ok, msg = importCode(xwEdit:GetText())
  xwMsg:SetText((ok and "|cff3ddc3d" or "|cffff6060") .. msg .. "|r")
  if ok then print(P .. msg); broadcast(true) end
end
xwGo:SetScript("OnClick", doImport)
xwEdit:SetScript("OnEnterPressed", function() if xwGo:IsShown() then doImport() else XW:Hide() end end)
xwEdit:SetScript("OnEscapePressed", function() XW:Hide() end)

------------------------------------------------------------------------
-- 9. Gourt rank on player tooltips
------------------------------------------------------------------------
local function unitTip(tt)
  local d = DB(); if not d or d.noRankTip then return end
  local _, unit = tt:GetUnit()
  if not unit or not UnitIsPlayer(unit) then return end
  local name = short(UnitName(unit))
  local got, tot, set
  if UnitIsUnit(unit, "player") then
    local _
    _, set, got, tot = myStatus()
  else
    local p = peers()[name]
    if not p then return end
    got, tot, set = p.got or 0, p.tot or 0, p.set
  end
  if tot == 0 then return end
  tt:AddLine(("|TInterface\\Icons\\INV_Shield_06:14:14:0:0:64:64:5:59:5:59|t |cffc07cff%s|r  |cffaaaaaa%d/%d %s|r"):format(rankOf(got, tot), got, tot, NS.SET_NAMES[set] or ""))
  tt:Show()
end

-- "Needed by" line on item tooltips
local function itemTip(tt, id)
  if not id or tt.ggNeed == id then return end
  local d = DB(); if not d then return end
  local who = needers(id)
  -- only list other people here; the main tooltip already covers you
  local others = {}
  for _, w in ipairs(who) do if not w:find("You", 1, true) then others[#others + 1] = w end end
  if #others == 0 then return end
  tt.ggNeed = id
  tt:AddLine("  Also needed by: " .. table.concat(others, ", "), 0.75, 0.49, 1, true)
  tt:Show()
end
if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
  TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tt) if tt == GameTooltip then unitTip(tt) end end)
  TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, data)
    local id = data and data.id
    if not id and tt.GetItem then local _, l = tt:GetItem(); id = linkID(l) end
    itemTip(tt, id)
  end)
elseif GameTooltip and GameTooltip.HookScript then
  GameTooltip:HookScript("OnTooltipSetUnit", unitTip)
  for _, n in ipairs({ "GameTooltip", "ItemRefTooltip" }) do
    local tt = _G[n]
    if tt and tt.HookScript then
      tt:HookScript("OnTooltipSetItem", function(self) local _, l = self:GetItem(); itemTip(self, linkID(l)) end)
    end
  end
end
for _, n in ipairs({ "GameTooltip", "ItemRefTooltip" }) do
  local tt = _G[n]
  if tt and tt.HookScript then tt:HookScript("OnTooltipCleared", function(self) self.ggNeed = nil end) end
end

------------------------------------------------------------------------
-- 10. Sounds
--    Put your own loot.ogg / wipe.ogg in Interface\AddOns\GourtsGearing\sounds to use them instead.
------------------------------------------------------------------------
local SOUNDS = {
  { key = "warning", name = "Raid warning horn", kit = function() return SOUNDKIT and SOUNDKIT.RAID_WARNING or 8959 end },
  { key = "levelup", name = "Level up fanfare", kit = function() return 888 end },
  { key = "quest", name = "Quest complete", kit = function() return SOUNDKIT and SOUNDKIT.IG_QUEST_LIST_COMPLETE or 878 end },
  { key = "ready", name = "Ready check", kit = function() return SOUNDKIT and SOUNDKIT.READY_CHECK or 8960 end },
  { key = "off", name = "Off" },
}
local nextKind = "loot"
NS.playSound = function()
  local kind = nextKind; nextKind = "loot"
  local d = DB(); local choice = (d and d.sound) or "warning"
  if choice == "off" then return end
  if PlaySoundFile then
    local ok, willPlay = pcall(PlaySoundFile, "Interface\\AddOns\\GourtsGearing\\sounds\\" .. kind .. ".ogg", "Master")
    if ok and willPlay then return end
  end
  for _, s in ipairs(SOUNDS) do
    if s.key == choice and s.kit and PlaySound then pcall(PlaySound, s.kit(), "Master"); return end
  end
end
local function cycleSound()
  local d = DB()
  local cur = 1
  for i, s in ipairs(SOUNDS) do if s.key == (d.sound or "warning") then cur = i end end
  local nx = SOUNDS[cur % #SOUNDS + 1]
  d.sound = nx.key
  print(P .. "celebration sound: " .. nx.name .. ".")
  NS.playSound()
end

------------------------------------------------------------------------
-- 11. Wipe jokes
------------------------------------------------------------------------
local WIPE = {
  "Typical Raze pull.", "Raze said \"just one more pack\".", "Gourt was AFK. The rest of Raze was not.",
  "Big Gourt would have lived.", "Run back. The Raze guild bank is not paying for repairs.", "That one's going in the Raze blooper reel.",
  "Even the trash is laughing.", "Somebody tell Raze where the healer is.", "Tank wasn't even in the group.",
  "Raze stood in the fire. As a guild. For the vibes.",
  "Vortex pulled. Vortex always pulls.", "Beth was OOM. Beth is always OOM.", "Deadonkillz lived up to the name.",
  "Jake rolled Need on the wipe.", "Emortal: HONK. That was the whole strategy.", "Doodlie, King of the Losers, leads by example.",
  "Afterr will explain what went wrong. After.", "Shamyss forgot the totems. Again.", "Turox is writing this one down for officer chat.",
  "Krixi was looting a chest during the pull.", "Lups asked what the boss does. Now we know.",
}
local DEATH = { "Raze guild chat is laughing at you.", "Gourt saw that. So did Turox.", "Drekzz will hear about this.", "Even Kew at level 9 didn't die there.", "Gourt saw that.", "The floor is not a bed.", "Spirit healer has you on speed dial." }
local lastWipe, watching = 0, false
local function groupAllDead()
  if not (IsInGroup and IsInGroup()) then return false end
  if not UnitIsDeadOrGhost("player") then return false end
  local raid = IsInRaid and IsInRaid()
  local n = GetNumGroupMembers and GetNumGroupMembers() or 0
  for i = 1, raid and n or (n - 1) do
    local u = raid and ("raid" .. i) or ("party" .. i)
    if UnitExists(u) and not UnitIsDeadOrGhost(u) and UnitIsConnected(u) then return false end
  end
  return true
end
local function wipeSplash(where)
  local d = DB(); if not d or d.noWipe then return end
  if GetTime() - lastWipe < 30 then return end
  lastWipe = GetTime()
  nextKind = "wipe"
  NS.splash("WIPE", where and (NS.pick(WIPE) .. "  (" .. where .. ")") or NS.pick(WIPE), NS.pick(NS.PICS))
end
local function onDeath()
  local d = DB(); if not d or d.noWipe then return end
  local inInst = IsInInstance()
  if not inInst then return end
  if not (IsInGroup and IsInGroup()) then print(P .. NS.pick(DEATH)); return end
  if watching then return end
  watching = true
  local tries = 0
  local function check()
    tries = tries + 1
    if groupAllDead() then watching = false; wipeSplash(); return end
    if tries < 30 and UnitIsDeadOrGhost("player") then after(1, check) else watching = false; print(P .. NS.pick(DEATH)) end
  end
  after(1, check)
end

------------------------------------------------------------------------
-- Buttons beside the menu + slash commands
------------------------------------------------------------------------
local TABS = {
  { "Guild", GW, "Guildmates' progress" },
  { "Planner", PW, "Which dungeon to run" },
  { "Gear check", CW, "What you're wearing vs your set" },
  { "Materials", MW, "Crafting materials you have" },
  { "Swap code", nil, "Share or load swaps" },
}
local M = NS.menu
if M then
  for i, t in ipairs(TABS) do
    local b = NS.button(M, t[1], 96, 24)
    b:SetPoint("TOPLEFT", M, "TOPRIGHT", 2, -14 - (i - 1) * 27)
    b:SetScript("OnClick", function(_, btn)
      if t[2] then if t[2]:IsShown() then t[2]:Hide() else t[2]:Show() end
      else openExport() end
    end)
    b:SetScript("OnEnter", function(self)
      GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:AddLine(t[3], 1, 1, 1)
      if not t[2] then GameTooltip:AddLine("Type /gp import to load a code.", 0.7, 0.7, 0.7) end
      GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  end
end

local function toggle(field, label)
  local d = DB(); d[field] = not d[field]
  print(P .. label .. " " .. (d[field] and "OFF" or "ON") .. ".")
end
local CMDS = {
  guild = function() GW:Show() end,
  plan = function() PW:Show() end, planner = function() PW:Show() end,
  check = function() CW:Show() end, gear = function() CW:Show() end,
  mats = function() MW:Show() end, materials = function() MW:Show() end,
  export = openExport, code = openExport, import = openImport,
  sound = cycleSound,
  sync = function() toggle("noSync", "sharing your progress is") end,
  ah = function() toggle("noAH", "Auction House highlights are") end,
  remind = function() toggle("noReminder", "dungeon reminders are") end,
  wipe = function() toggle("noWipe", "wipe jokes are") end,
  ranktip = function() toggle("noRankTip", "ranks on player tooltips are") end,
  help = function()
    print(P .. "commands: /gp (menu), arrow, set, spec, guild, plan, check, mats, export, import, sound, sync, ah, remind, wipe, ranktip, autotick, glow, reset")
  end,
}
SlashCmdList.GEARPATH = function(msg)
  local m = (msg or ""):lower():match("^%s*(.-)%s*$")
  if CMDS[m] then CMDS[m]() else NS.slash(msg) end
end

------------------------------------------------------------------------
-- Events
------------------------------------------------------------------------
local sig
local function changed()
  local _, set, got, tot = myStatus()
  local s = set .. got .. "/" .. tot
  if s ~= sig then
    sig = s
    broadcast()
    if GW:IsShown() then drawGuild() end
    if PW:IsShown() then drawPlanner() end
    if MW:IsShown() then drawMats() end
  end
end
onPeerUpdate = function()
  if GW:IsShown() then drawGuild() end
  if PW:IsShown() then drawPlanner() end
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_LOGIN", "CHAT_MSG_ADDON", "GROUP_ROSTER_UPDATE", "START_LOOT_ROLL", "LOOT_OPENED",
  "PLAYER_ENTERING_WORLD", "ZONE_CHANGED_NEW_AREA", "PLAYER_EQUIPMENT_CHANGED", "BAG_UPDATE_DELAYED", "BANKFRAME_OPENED",
  "AUCTION_HOUSE_SHOW", "AUCTION_ITEM_LIST_UPDATE", "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED", "PLAYER_DEAD", "ENCOUNTER_END" }) do
  pcall(ev.RegisterEvent, ev, e)
end
ev:SetScript("OnEvent", function(_, e, a1, a2, a3, a4, a5)
  local d = DB(); if not d then return end
  if e == "PLAYER_LOGIN" then
    regPrefix()
    d.peers = d.peers or {}
    for name, p in pairs(d.peers) do if now() - (p.t or 0) > 14 * 86400 then d.peers[name] = nil end end
    after(8, function()
      if IsInGuild and IsInGuild() and not d.noSync then send("R", "GUILD") end
      broadcast(true)
    end)
    if C_Timer and C_Timer.NewTicker then C_Timer.NewTicker(5, changed) end
  elseif e == "CHAT_MSG_ADDON" then onAddonMsg(a1, a2, a3, a4)
  elseif e == "GROUP_ROSTER_UPDATE" then
    after(3, function() local g = groupChan(); if g then lastMsg[g] = nil end; broadcast() end)
  elseif e == "START_LOOT_ROLL" then onRoll(a1)
  elseif e == "LOOT_OPENED" then onLootOpened()
  elseif e == "PLAYER_ENTERING_WORLD" or e == "ZONE_CHANGED_NEW_AREA" then after(4, checkInstance)
  elseif e == "PLAYER_EQUIPMENT_CHANGED" or e == "BAG_UPDATE_DELAYED" then
    markPaperDoll(); if CW:IsShown() then drawCheck() end; if MW:IsShown() then drawMats() end
  elseif e == "BANKFRAME_OPENED" then
    after(0.5, function() d.bank = scanContainers(bankBags()); if MW:IsShown() then drawMats() end end)
  elseif e == "AUCTION_HOUSE_SHOW" then hookAH()
  elseif e == "AUCTION_ITEM_LIST_UPDATE" then hookAH(); after(0, scanBrowse)
  elseif e == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" then scanModernAH()
  elseif e == "PLAYER_DEAD" then onDeath()
  elseif e == "ENCOUNTER_END" then
    if a5 == 0 and IsInInstance() then after(2, function() if groupAllDead() then wipeSplash(a2) end end) end
  end
end)

-- for testing
NS.extras = { needers = needers, statusMsg = statusMsg, onAddonMsg = onAddonMsg, dungeonNeeds = dungeonNeeds, DUNGEONS = DUNGEONS,
  gearState = gearState, importCode = importCode, exportCode = exportCode, scanContainers = scanContainers, drawMats = drawMats,
  drawGuild = drawGuild, drawPlanner = drawPlanner, drawCheck = drawCheck, checkInstance = checkInstance, wipeSplash = wipeSplash }
