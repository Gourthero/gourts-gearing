Put your own sounds here to replace the built-in ones:
  loot.ogg  plays when you loot a piece of your set
  wipe.ogg  plays when your group wipes in a dungeon
They must be .ogg files. Restart WoW (not just /reload) after adding new files.
Change the built-in sound with /gp sound.
